Place broker-exported XAUUSD candles here. No sample market data is bundled, to avoid confusing synthetic data with historical prices.

For the intended MT5 workflow on Windows, run from the project root:

```powershell
python main.py export-bars --bars 5000 --output data\XAUUSD_M5.csv
```

The exporter reads from the MT5 terminal after validating that the connected account is a DEMO account. Alternatively, provide your own historical CSV with `open`, `high`, `low`, `close` and preferably a `time` or `timestamp` column.
