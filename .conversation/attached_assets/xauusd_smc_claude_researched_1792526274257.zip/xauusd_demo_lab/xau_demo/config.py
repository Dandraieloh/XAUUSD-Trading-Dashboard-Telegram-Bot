from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class StrategyConfig:
    fast_ema: int = 20
    slow_ema: int = 50
    rsi_period: int = 14
    atr_period: int = 14
    long_rsi_min: float = 52.0
    long_rsi_max: float = 72.0
    short_rsi_min: float = 28.0
    short_rsi_max: float = 48.0
    atr_stop_multiple: float = 1.5
    reward_risk: float = 2.0

    def validate(self) -> None:
        if min(self.fast_ema, self.slow_ema, self.rsi_period, self.atr_period) < 2:
            raise ValueError("Indicator periods must be at least 2")
        if self.fast_ema >= self.slow_ema:
            raise ValueError("fast_ema must be smaller than slow_ema")
        if self.atr_stop_multiple <= 0 or self.reward_risk <= 0:
            raise ValueError("Stop multiple and reward/risk must be positive")


@dataclass(frozen=True)
class RiskConfig:
    risk_per_trade_pct: float = 0.25
    daily_loss_limit_pct: float = 2.0
    max_spread_price: float = 1.50
    max_lots: float = 1.0
    magic: int = 20261020
    deviation_points: int = 30
    volume_min_fallback: float = 0.01
    volume_step_fallback: float = 0.01

    def validate(self) -> None:
        if not 0 < self.risk_per_trade_pct <= 1.0:
            raise ValueError("risk_per_trade_pct must be > 0 and <= 1% (percent, not fraction)")
        if not 0 < self.daily_loss_limit_pct <= 5:
            raise ValueError("daily_loss_limit_pct must be > 0 and <= 5%")
        if self.max_spread_price <= 0 or self.max_lots <= 0:
            raise ValueError("Spread limit and max_lots must be positive")


@dataclass(frozen=True)
class AppConfig:
    symbol: str = "XAUUSD"
    timeframe_name: str = "M5"
    poll_seconds: float = 3.0
    bars_required: int = 300
    strategy: StrategyConfig = StrategyConfig()
    risk: RiskConfig = RiskConfig()
    smc_swing_length: int = 3
    smc_event_lookback: int = 20
    atr_period_smc: int = 14
    htf_timeframes: tuple[str, ...] = ("H1", "H4")
    confidence_threshold: float = 0.70
    anthropic_daily_budget_usd: float = 2.0
    anthropic_input_usd_per_mtok: float = 3.0
    anthropic_output_usd_per_mtok: float = 15.0
    research_enabled: bool = True
    research_max_results: int = 3
    learning_db_path: str = "state/learning.sqlite3"
    learning_min_setup_sample: int = 8
    anthropic_model: str = "claude-sonnet-4-6"

    @classmethod
    def from_env(cls) -> "AppConfig":
        risk = RiskConfig(
            risk_per_trade_pct=float(os.getenv("RISK_PER_TRADE_PCT", "0.25")),
            daily_loss_limit_pct=float(os.getenv("DAILY_LOSS_LIMIT_PCT", "2.0")),
            max_spread_price=float(os.getenv("MAX_SPREAD_PRICE", "1.50")),
            max_lots=float(os.getenv("MAX_LOTS", "1.0")),
            magic=int(os.getenv("MT5_MAGIC", "20261020")),
            deviation_points=int(os.getenv("MT5_DEVIATION_POINTS", "30")),
        )
        strategy = StrategyConfig(
            fast_ema=int(os.getenv("FAST_EMA", "20")),
            slow_ema=int(os.getenv("SLOW_EMA", "50")),
            rsi_period=int(os.getenv("RSI_PERIOD", "14")),
            atr_period=int(os.getenv("ATR_PERIOD", "14")),
            long_rsi_min=float(os.getenv("LONG_RSI_MIN", "52")),
            long_rsi_max=float(os.getenv("LONG_RSI_MAX", "72")),
            short_rsi_min=float(os.getenv("SHORT_RSI_MIN", "28")),
            short_rsi_max=float(os.getenv("SHORT_RSI_MAX", "48")),
            atr_stop_multiple=float(os.getenv("ATR_STOP_MULTIPLE", "1.5")),
            reward_risk=float(os.getenv("REWARD_RISK", "2.0")),
        )
        cfg = cls(
            symbol=os.getenv("MT5_SYMBOL", "XAUUSD"),
            timeframe_name=os.getenv("MT5_TIMEFRAME", "M5").upper(),
            poll_seconds=float(os.getenv("POLL_SECONDS", "3")),
            bars_required=int(os.getenv("BARS_REQUIRED", "300")),
            strategy=strategy,
            risk=risk,
            smc_swing_length=int(os.getenv("SMC_SWING_LENGTH", "3")),
            smc_event_lookback=int(os.getenv("SMC_EVENT_LOOKBACK", "20")),
            atr_period_smc=int(os.getenv("ATR_PERIOD", "14")),
            htf_timeframes=tuple(x.strip().upper() for x in os.getenv("HTF_TIMEFRAMES", "H1,H4").split(",") if x.strip()),
            confidence_threshold=float(os.getenv("ANTHROPIC_CONFIDENCE_THRESHOLD", "0.70")),
            anthropic_daily_budget_usd=float(os.getenv("ANTHROPIC_DAILY_BUDGET_USD", "2.00")),
            anthropic_input_usd_per_mtok=float(os.getenv("ANTHROPIC_INPUT_USD_PER_MTOK", "3.00")),
            anthropic_output_usd_per_mtok=float(os.getenv("ANTHROPIC_OUTPUT_USD_PER_MTOK", "15.00")),
            research_enabled=os.getenv("RESEARCH_ENABLED", "true").strip().lower() not in {"0", "false", "no", "off"},
            research_max_results=int(os.getenv("RESEARCH_MAX_RESULTS", "3")),
            learning_db_path=os.getenv("LEARNING_DB_PATH", "state/learning.sqlite3"),
            learning_min_setup_sample=int(os.getenv("LEARNING_MIN_SETUP_SAMPLE", "8")),
            anthropic_model=os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4-6"),
        )
        cfg.strategy.validate()
        cfg.risk.validate()
        if cfg.timeframe_name not in {"M1", "M5", "M15", "M30", "H1", "H4", "D1"}:
            raise ValueError("MT5_TIMEFRAME must be one of M1, M5, M15, M30, H1, H4, D1")
        if cfg.smc_swing_length < 2 or cfg.smc_event_lookback < 3:
            raise ValueError("SMC_SWING_LENGTH must be >=2 and SMC_EVENT_LOOKBACK >=3")
        if not 0 <= cfg.confidence_threshold <= 1:
            raise ValueError("ANTHROPIC_CONFIDENCE_THRESHOLD must be between 0 and 1")
        if cfg.anthropic_daily_budget_usd < 0 or cfg.anthropic_input_usd_per_mtok < 0 or cfg.anthropic_output_usd_per_mtok < 0:
            raise ValueError("Anthropic budget and token prices cannot be negative")
        if cfg.research_max_results < 1 or cfg.research_max_results > 10:
            raise ValueError("RESEARCH_MAX_RESULTS must be between 1 and 10")
        if cfg.learning_min_setup_sample < 3:
            raise ValueError("LEARNING_MIN_SETUP_SAMPLE must be at least 3")
        if any(tf not in {"M1", "M5", "M15", "M30", "H1", "H4", "D1"} for tf in cfg.htf_timeframes):
            raise ValueError("HTF_TIMEFRAMES contains an unsupported MT5 timeframe")
        if cfg.poll_seconds <= 0 or cfg.bars_required < max(cfg.strategy.slow_ema, cfg.strategy.atr_period) + 5:
            raise ValueError("poll seconds must be positive and bars_required must cover indicator warm-up")
        return cfg
