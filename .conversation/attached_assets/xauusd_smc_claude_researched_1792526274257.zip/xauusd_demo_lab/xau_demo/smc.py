from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class SMCConfig:
    swing_length: int = 3
    event_lookback: int = 20
    atr_period: int = 14

    def validate(self) -> None:
        if self.swing_length < 2 or self.event_lookback < 3 or self.atr_period < 2:
            raise ValueError("SMC swing_length >= 2, event_lookback >= 3, and atr_period >= 2 are required")


def _require_ohlc(frame: pd.DataFrame) -> pd.DataFrame:
    required = {"open", "high", "low", "close"}
    missing = required - {str(c).lower() for c in frame.columns}
    if missing:
        raise ValueError(f"Candles missing required columns: {', '.join(sorted(missing))}")
    out = frame.copy()
    out.columns = [str(c).lower() for c in out.columns]
    out = out.reset_index(drop=True)
    for col in ("open", "high", "low", "close"):
        out[col] = pd.to_numeric(out[col], errors="coerce")
    out = out.dropna(subset=["open", "high", "low", "close"]).reset_index(drop=True)
    if len(out) < 30:
        raise ValueError("At least 30 completed candles are required for SMC analysis")
    if (out["high"] < out["low"]).any():
        raise ValueError("Invalid candle data: high below low")
    return out


def _atr(frame: pd.DataFrame, period: int) -> pd.Series:
    previous_close = frame["close"].shift(1)
    true_range = pd.concat(
        [frame["high"] - frame["low"], (frame["high"] - previous_close).abs(), (frame["low"] - previous_close).abs()],
        axis=1,
    ).max(axis=1)
    return true_range.ewm(alpha=1 / period, min_periods=period, adjust=False).mean()


def calculate_trend(candles: pd.DataFrame) -> dict[str, Any]:
    """Return a transparent EMA trend filter for one timeframe."""
    frame = _require_ohlc(candles)
    close = frame["close"]
    fast = close.ewm(span=20, adjust=False).mean()
    slow = close.ewm(span=50, adjust=False).mean()
    slope = float(fast.iloc[-1] - fast.iloc[-4]) if len(fast) >= 4 else 0.0
    price = float(close.iloc[-1])
    if float(fast.iloc[-1]) > float(slow.iloc[-1]) and slope > 0 and price > float(fast.iloc[-1]):
        direction = "BULLISH"
    elif float(fast.iloc[-1]) < float(slow.iloc[-1]) and slope < 0 and price < float(fast.iloc[-1]):
        direction = "BEARISH"
    else:
        direction = "RANGING"
    return {
        "direction": direction,
        "close": price,
        "ema20": float(fast.iloc[-1]),
        "ema50": float(slow.iloc[-1]),
        "ema20_slope_3_bars": slope,
    }


def _confirm_swings(frame: pd.DataFrame, strength: int) -> tuple[list[float | None], list[float | None]]:
    """Mark pivots only on their confirmation candle (no future information at decision time)."""
    highs = frame["high"].to_numpy(dtype=float)
    lows = frame["low"].to_numpy(dtype=float)
    confirmed_high: list[float | None] = [None] * len(frame)
    confirmed_low: list[float | None] = [None] * len(frame)
    for pivot in range(strength, len(frame) - strength):
        left, right = pivot - strength, pivot + strength + 1
        window_high = highs[left:right]
        window_low = lows[left:right]
        if highs[pivot] == np.max(window_high) and int(np.sum(window_high == highs[pivot])) == 1:
            confirmed_high[pivot + strength] = float(highs[pivot])
        if lows[pivot] == np.min(window_low) and int(np.sum(window_low == lows[pivot])) == 1:
            confirmed_low[pivot + strength] = float(lows[pivot])
    return confirmed_high, confirmed_low


def analyse_smc(
    candles: pd.DataFrame,
    higher_timeframes: dict[str, pd.DataFrame] | None = None,
    config: SMCConfig | None = None,
) -> dict[str, Any]:
    """Build a compact, causal SMC + trend snapshot from *completed* candles.

    This is a transparent rule-based approximation of market structure and zones,
    not an authoritative reading of institutional order flow.
    """
    cfg = config or SMCConfig()
    cfg.validate()
    frame = _require_ohlc(candles)
    frame["atr"] = _atr(frame, cfg.atr_period)
    frame["ema20"] = frame["close"].ewm(span=20, adjust=False).mean()
    frame["ema50"] = frame["close"].ewm(span=50, adjust=False).mean()
    confirmed_high, confirmed_low = _confirm_swings(frame, cfg.swing_length)

    structure_events: list[str] = ["NONE"] * len(frame)
    sweep_events: list[str] = ["NONE"] * len(frame)
    swing_high_series: list[float | None] = [None] * len(frame)
    swing_low_series: list[float | None] = [None] * len(frame)
    last_high: float | None = None
    last_low: float | None = None
    bias = 0
    for i, row in frame.iterrows():
        previous_close = float(frame.iloc[i - 1]["close"]) if i > 0 else float(row["close"])
        # Only levels already confirmed before this candle may be broken/swept by it.
        swing_high_series[i] = last_high
        swing_low_series[i] = last_low
        high = float(row["high"])
        low = float(row["low"])
        close = float(row["close"])
        if last_high is not None and high > last_high and close < last_high:
            sweep_events[i] = "BUY_SIDE_SWEEP"
        elif last_low is not None and low < last_low and close > last_low:
            sweep_events[i] = "SELL_SIDE_SWEEP"

        broke_up = last_high is not None and close > last_high and previous_close <= last_high
        broke_down = last_low is not None and close < last_low and previous_close >= last_low
        if broke_up:
            structure_events[i] = "CHoCH_UP" if bias < 0 else "BOS_UP"
            bias = 1
        elif broke_down:
            structure_events[i] = "CHoCH_DOWN" if bias > 0 else "BOS_DOWN"
            bias = -1

        # Swings detected with right-side candles become available only now.
        if confirmed_high[i] is not None:
            last_high = confirmed_high[i]
        if confirmed_low[i] is not None:
            last_low = confirmed_low[i]

    frame["structure_event"] = structure_events
    frame["liquidity_sweep"] = sweep_events
    frame["swing_high"] = swing_high_series
    frame["swing_low"] = swing_low_series

    # Maintain active FVGs; a zone is removed once price traverses its far edge.
    active_fvgs: list[dict[str, Any]] = []
    fvg_by_index: list[dict[str, Any] | None] = [None] * len(frame)
    highs = frame["high"].to_numpy(dtype=float)
    lows = frame["low"].to_numpy(dtype=float)
    for i in range(len(frame)):
        if i >= 2:
            # Bullish gap: current low above high from two candles earlier.
            if lows[i] > highs[i - 2]:
                active_fvgs.append({"side": "BUY", "bottom": float(highs[i - 2]), "top": float(lows[i]), "formed_index": i})
            # Bearish gap: current high below low from two candles earlier.
            if highs[i] < lows[i - 2]:
                active_fvgs.append({"side": "SELL", "bottom": float(highs[i]), "top": float(lows[i - 2]), "formed_index": i})
        updated = []
        for zone in active_fvgs:
            if zone["side"] == "BUY" and lows[i] > zone["bottom"]:
                updated.append(zone)
            elif zone["side"] == "SELL" and highs[i] < zone["top"]:
                updated.append(zone)
        active_fvgs = updated
        fvg_by_index[i] = [dict(zone) for zone in active_fvgs]

    # Track simple opposing-candle order-block proxies after a structure break.
    active_obs: list[dict[str, Any]] = []
    ob_by_index: list[dict[str, Any] | None] = [None] * len(frame)
    for i in range(len(frame)):
        close = float(frame.iloc[i]["close"])
        low = float(frame.iloc[i]["low"])
        high = float(frame.iloc[i]["high"])
        event = structure_events[i]
        if event in {"BOS_UP", "CHoCH_UP", "BOS_DOWN", "CHoCH_DOWN"}:
            side = "BUY" if event.endswith("UP") else "SELL"
            for j in range(i - 1, max(-1, i - 7), -1):
                candle = frame.iloc[j]
                bearish = float(candle["close"]) < float(candle["open"])
                bullish = float(candle["close"]) > float(candle["open"])
                if (side == "BUY" and bearish) or (side == "SELL" and bullish):
                    active_obs.append({"side": side, "bottom": float(candle["low"]), "top": float(candle["high"]), "formed_index": j, "break_index": i})
                    break
        still_active = []
        for zone in active_obs:
            if zone["side"] == "BUY" and low > zone["bottom"] and close >= zone["bottom"]:
                still_active.append(zone)
            elif zone["side"] == "SELL" and high < zone["top"] and close <= zone["top"]:
                still_active.append(zone)
        active_obs = still_active
        ob_by_index[i] = [dict(zone) for zone in active_obs]

    frame["fvg"] = fvg_by_index
    frame["order_block"] = ob_by_index
    last = frame.iloc[-1]
    trend = calculate_trend(frame)
    htf = {name.upper(): calculate_trend(data) for name, data in (higher_timeframes or {}).items() if data is not None and len(data) >= 55}
    close = float(last["close"])
    atr = float(last["atr"]) if pd.notna(last["atr"]) else 0.0
    lookback_start = max(0, len(frame) - cfg.event_lookback)
    recent = frame.iloc[lookback_start:].reset_index(drop=True)
    structure_positions = [i for i, value in enumerate(recent["structure_event"].tolist()) if value != "NONE"]
    latest_event = "NONE"
    event_pos: int | None = None
    if structure_positions:
        event_pos = structure_positions[-1]
        latest_event = str(recent.iloc[event_pos]["structure_event"])
    direction = "BUY" if latest_event.endswith("UP") else "SELL" if latest_event.endswith("DOWN") else "HOLD"
    expected_sweep = "SELL_SIDE_SWEEP" if direction == "BUY" else "BUY_SIDE_SWEEP" if direction == "SELL" else "NONE"
    sweep_positions = [i for i, value in enumerate(recent["liquidity_sweep"].tolist()) if expected_sweep != "NONE" and value == expected_sweep]
    qualifying_sweeps = [i for i in sweep_positions if event_pos is None or i <= event_pos]
    sweep_after_context = bool(direction in {"BUY", "SELL"} and qualifying_sweeps)
    sweep_detail = None
    if sweep_after_context:
        sweep_relative_index = qualifying_sweeps[-1]
        sweep_row = recent.iloc[sweep_relative_index]
        sweep_detail = {
            "type": expected_sweep,
            "extreme": float(sweep_row["low"] if direction == "BUY" else sweep_row["high"]),
            "confirmed_at": str(sweep_row["time"]) if "time" in recent.columns else None,
            "bars_before_structure": max(0, (event_pos or 0) - sweep_relative_index),
        }

    active_fvg_list = last["fvg"] if isinstance(last["fvg"], list) else []
    active_ob_list = last["order_block"] if isinstance(last["order_block"], list) else []
    matching_fvgs = [z for z in active_fvg_list if z.get("side") == direction and len(frame) - 1 - int(z["formed_index"]) <= cfg.event_lookback]
    matching_obs = [z for z in active_ob_list if z.get("side") == direction and len(frame) - 1 - int(z["break_index"]) <= cfg.event_lookback]
    fvg = max(matching_fvgs, key=lambda z: int(z["formed_index"])) if matching_fvgs else None
    order_block = max(matching_obs, key=lambda z: int(z["break_index"])) if matching_obs else None
    matching_fvg = fvg is not None
    matching_ob = order_block is not None
    all_fvgs_by_side = {
        side: max([z for z in active_fvg_list if z.get("side") == side], key=lambda z: int(z["formed_index"]), default=None)
        for side in ("BUY", "SELL")
    }
    all_obs_by_side = {
        side: max([z for z in active_ob_list if z.get("side") == side], key=lambda z: int(z["break_index"]), default=None)
        for side in ("BUY", "SELL")
    }
    def display_zone(zone: dict[str, Any] | None, age_key: str) -> dict[str, Any] | None:
        if not zone:
            return None
        return {
            "bottom": float(zone["bottom"]),
            "top": float(zone["top"]),
            "age_candles": max(0, len(frame) - 1 - int(zone[age_key])),
        }
    htf_directions = {name: value["direction"] for name, value in htf.items()}
    htf_agrees = all(value == ("BULLISH" if direction == "BUY" else "BEARISH") for value in htf_directions.values()) if htf_directions and direction in {"BUY", "SELL"} else False
    trend_agrees = trend["direction"] == ("BULLISH" if direction == "BUY" else "BEARISH") if direction in {"BUY", "SELL"} else False
    has_zone = matching_fvg or matching_ob
    candidate = direction if direction in {"BUY", "SELL"} and trend_agrees and htf_agrees and sweep_after_context and has_zone and atr > 0 else "HOLD"

    reasons = []
    reasons.append(f"Trend filter: {trend['direction']} on execution timeframe")
    reasons.append(f"Latest structure event: {latest_event}")
    reasons.append("Required liquidity sweep found before/at structure event" if sweep_after_context else "No qualifying prior liquidity sweep")
    if matching_fvg:
        reasons.append("Active same-direction fair value gap")
    if matching_ob:
        reasons.append("Active same-direction opposing-candle order-block proxy")
    if htf_directions:
        reasons.append("Higher timeframe trend: " + ", ".join(f"{k}={v}" for k, v in htf_directions.items()))
    else:
        reasons.append("Higher-timeframe confirmation unavailable")
    if not htf_agrees:
        reasons.append("Higher timeframes do not fully align; no entry")
    if not trend_agrees:
        reasons.append("Execution-timeframe trend does not align; no entry")
    if not has_zone:
        reasons.append("No active same-direction FVG/order-block zone")

    zone_flags = "+".join(name for name, yes in (("FVG", matching_fvg), ("OB", matching_ob)) if yes) or "NO_ZONE"
    sweep_tag = expected_sweep if sweep_after_context else "NO_SWEEP"
    setup_key = f"{candidate}|{latest_event}|{sweep_tag}|{zone_flags}|" + ",".join(f"{k}:{v}" for k, v in sorted(htf_directions.items()))
    timestamp = str(last["time"]) if "time" in frame.columns else None
    return {
        "timestamp": timestamp,
        "close": close,
        "atr": atr,
        "trend": trend,
        "structure_event": latest_event,
        "structure_bias": int(bias),
        "recent_liquidity_sweep": expected_sweep if sweep_after_context else "NONE",
        "liquidity_sweep_detail": sweep_detail,
        "swing_high": float(last["swing_high"]) if pd.notna(last["swing_high"]) else None,
        "swing_low": float(last["swing_low"]) if pd.notna(last["swing_low"]) else None,
        "fvg": {k: v for k, v in fvg.items() if k != "formed_index"} if matching_fvg and fvg else None,
        "order_block": {k: v for k, v in order_block.items() if k not in {"formed_index", "break_index"}} if matching_ob and order_block else None,
        "active_zones": {
            "fair_value_gaps": {side: display_zone(zone, "formed_index") for side, zone in all_fvgs_by_side.items() if zone},
            "order_blocks": {side: display_zone(zone, "break_index") for side, zone in all_obs_by_side.items() if zone},
        },
        "higher_timeframes": htf,
        "setup_candidate": candidate,
        "setup_key": setup_key,
        "reasons": reasons,
        "execution_policy": "CLOSED_CANDLES_ONLY; LLM_MAY_VETO_NOT_CREATE_OR_REVERSE_SETUPS",
    }
