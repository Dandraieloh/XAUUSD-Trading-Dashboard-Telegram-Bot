from __future__ import annotations

import json
import math
from pathlib import Path

import pandas as pd

from .config import StrategyConfig
from .strategy import add_indicators


def load_candles_csv(path: str | Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    df.columns = [str(c).strip().lower() for c in df.columns]
    for alias in ("timestamp", "datetime", "date", "time"):
        if alias in df.columns:
            df["time"] = pd.to_datetime(df[alias], utc=True, errors="coerce")
            break
    if "time" not in df.columns:
        df["time"] = pd.RangeIndex(start=0, stop=len(df), step=1)
    return df


def run_backtest(
    candles: pd.DataFrame,
    strategy: StrategyConfig | None = None,
    initial_equity: float = 10_000.0,
    risk_pct: float = 0.25,
    contract_units_per_lot: float = 100.0,
    assumed_spread_price: float = 0.30,
    slippage_price_per_side: float = 0.05,
    volume_step: float = 0.01,
    min_volume: float = 0.01,
    max_volume: float = 1.0,
) -> tuple[pd.DataFrame, dict]:
    """Simple OHLC backtest with next-bar entries and pessimistic dual-hit handling.

    Price/cost assumptions vary by broker. Gold contract units, spread and
    slippage are explicit inputs and are not inferred from the CSV.
    """
    if initial_equity <= 0 or not 0 < risk_pct <= 1:
        raise ValueError("initial_equity must be positive and risk_pct must be in (0, 1]")
    if contract_units_per_lot <= 0 or assumed_spread_price < 0 or slippage_price_per_side < 0:
        raise ValueError("Contract units must be positive and assumed costs non-negative")
    if volume_step <= 0 or min_volume <= 0 or max_volume < min_volume:
        raise ValueError("Invalid volume constraints")

    cfg = strategy or StrategyConfig()
    df = add_indicators(candles, cfg)
    if len(df) < max(cfg.slow_ema, cfg.atr_period, cfg.rsi_period) + 3:
        raise ValueError("Not enough candles for indicator warm-up")

    equity = float(initial_equity)
    peak_equity = equity
    max_drawdown = 0.0
    position: dict | None = None
    records: list[dict] = []

    def finish_position(exit_i: int, exit_reference: float, reason: str) -> None:
        nonlocal equity, peak_equity, max_drawdown, position, records
        assert position is not None
        side = int(position["side"])
        exit_fill = exit_reference - side * (assumed_spread_price / 2 + slippage_price_per_side)
        pnl = side * (exit_fill - float(position["entry_fill"])) * contract_units_per_lot * float(position["volume"])
        equity += pnl
        peak_equity = max(peak_equity, equity)
        dd = 0.0 if peak_equity <= 0 else (peak_equity - equity) / peak_equity * 100.0
        max_drawdown = max(max_drawdown, dd)
        records.append({
            "entry_time": position["entry_time"],
            "side": "BUY" if side == 1 else "SELL",
            "volume": position["volume"],
            "entry_price": round(float(position["entry_fill"]), 5),
            "stop_loss": round(float(position["sl"]), 5),
            "take_profit": round(float(position["tp"]), 5),
            "exit_time": str(df.iloc[exit_i].get("time", exit_i)),
            "exit_price": round(float(exit_fill), 5),
            "exit_reason": reason,
            "pnl": round(pnl, 2),
            "equity_after": round(equity, 2),
        })
        position = None

    warmup = max(cfg.slow_ema, cfg.rsi_period, cfg.atr_period) + 1
    for i in range(warmup, len(df)):
        bar = df.iloc[i]
        bar_time = str(bar.get("time", i))
        position_open_at_start = position is not None

        if position_open_at_start:
            side = int(position["side"])
            hit_sl = float(bar["low"]) <= position["sl"] if side == 1 else float(bar["high"]) >= position["sl"]
            hit_tp = float(bar["high"]) >= position["tp"] if side == 1 else float(bar["low"]) <= position["tp"]
            # If both levels were crossed in one OHLC candle, assume the stop was hit first.
            if hit_sl:
                finish_position(i, float(position["sl"]), "SL" if not hit_tp else "SL_BOTH_LEVELS_TOUCHED")
            elif hit_tp:
                finish_position(i, float(position["tp"]), "TP")
            continue

        signal = int(df.iloc[i - 1]["signal"])  # previous, completed candle -> current open
        atr = float(df.iloc[i - 1]["atr"]) if pd.notna(df.iloc[i - 1]["atr"]) else math.nan
        if signal == 0 or not math.isfinite(atr) or atr <= 0:
            continue

        reference_entry = float(bar["open"])
        stop_distance = atr * cfg.atr_stop_multiple
        # Risk sizing uses the declared contract-unit assumption, rounded down to volume step.
        risk_cash = equity * risk_pct / 100.0
        # Include assumed round-trip friction in sizing so estimated loss at SL
        # does not ignore the spread and adverse slippage baked into simulated fills.
        per_lot_risk = (stop_distance + assumed_spread_price + 2 * slippage_price_per_side) * contract_units_per_lot
        volume_raw = min(risk_cash / per_lot_risk, max_volume)
        volume = math.floor((volume_raw + 1e-12) / volume_step) * volume_step
        volume = round(volume, 8)
        if volume + 1e-12 < min_volume or volume * per_lot_risk > risk_cash + 1e-6:
            continue

        entry_fill = reference_entry + signal * (assumed_spread_price / 2 + slippage_price_per_side)
        position = {
            "side": signal,
            "entry_time": bar_time,
            "entry_fill": entry_fill,
            "sl": reference_entry - signal * stop_distance,
            "tp": reference_entry + signal * stop_distance * cfg.reward_risk,
            "volume": volume,
        }
        # Also check the entry candle; if both levels touched, resolve pessimistically at SL.
        hit_sl = float(bar["low"]) <= position["sl"] if signal == 1 else float(bar["high"]) >= position["sl"]
        hit_tp = float(bar["high"]) >= position["tp"] if signal == 1 else float(bar["low"]) <= position["tp"]
        if hit_sl:
            finish_position(i, float(position["sl"]), "SL" if not hit_tp else "SL_BOTH_LEVELS_TOUCHED")
        elif hit_tp:
            finish_position(i, float(position["tp"]), "TP")

    if position is not None:
        finish_position(len(df) - 1, float(df.iloc[-1]["close"]), "END_OF_DATA")

    trades = pd.DataFrame.from_records(records)
    pnls = trades["pnl"] if not trades.empty else pd.Series(dtype=float)
    wins = pnls[pnls > 0]
    losses = pnls[pnls < 0]
    gross_profit = float(wins.sum())
    gross_loss = float(-losses.sum())
    summary = {
        "initial_equity": round(float(initial_equity), 2),
        "ending_equity": round(float(equity), 2),
        "net_pnl": round(float(equity - initial_equity), 2),
        "return_pct": round((equity / initial_equity - 1) * 100, 3),
        "closed_trades": int(len(trades)),
        "win_rate_pct": round(float((pnls > 0).mean() * 100), 2) if len(pnls) else 0.0,
        "profit_factor": round(gross_profit / gross_loss, 3) if gross_loss else (None if gross_profit == 0 else "infinite"),
        "max_closed_trade_drawdown_pct": round(max_drawdown, 3),
        "gross_profit": round(gross_profit, 2),
        "gross_loss": round(gross_loss, 2),
        "assumptions": {
            "risk_per_trade_pct": risk_pct,
            "contract_units_per_lot": contract_units_per_lot,
            "assumed_spread_price": assumed_spread_price,
            "slippage_price_per_side": slippage_price_per_side,
            "volume_step": volume_step,
            "minimum_volume": min_volume,
            "maximum_volume": max_volume,
            "execution": "signal on completed candle; entry at following candle open; stop-first if SL and TP both hit in one candle",
        },
    }
    return trades, summary


def save_backtest_report(trades: pd.DataFrame, summary: dict, out_dir: str | Path = "reports") -> tuple[Path, Path]:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    trades_path = out / "backtest_trades.csv"
    summary_path = out / "backtest_summary.json"
    trades.to_csv(trades_path, index=False)
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return trades_path, summary_path
