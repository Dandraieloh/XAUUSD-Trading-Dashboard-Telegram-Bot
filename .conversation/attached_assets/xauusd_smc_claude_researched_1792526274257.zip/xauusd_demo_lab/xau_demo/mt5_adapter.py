from __future__ import annotations

import os
from pathlib import Path

import pandas as pd


class SafetyStop(RuntimeError):
    """Raised when execution cannot be proven to be on an MT5 demo account."""


class MT5Adapter:
    """Small MetaTrader 5 adapter with a hard demo-account execution gate.

    The MetaTrader5 Python package is Windows-only. This module imports it at
    runtime so CSV backtests can run on other operating systems.
    """

    TIMEFRAMES = {"M1": "TIMEFRAME_M1", "M5": "TIMEFRAME_M5", "M15": "TIMEFRAME_M15",
                  "M30": "TIMEFRAME_M30", "H1": "TIMEFRAME_H1", "H4": "TIMEFRAME_H4", "D1": "TIMEFRAME_D1"}

    def __init__(self, symbol: str = "XAUUSD", timeframe: str = "M5", terminal_path: str | None = None):
        self.symbol = symbol
        self.timeframe_name = timeframe.upper()
        self.terminal_path = terminal_path or os.getenv("MT5_PATH") or None
        self.mt5 = None

    @staticmethod
    def _is_gold_symbol(symbol: str) -> bool:
        cleaned = symbol.upper().replace("/", "").replace(".", "").replace("_", "").replace("-", "")
        return cleaned.startswith("XAUUSD") or cleaned.startswith("GOLD")

    def connect_demo(self) -> None:
        if not self._is_gold_symbol(self.symbol):
            raise SafetyStop(f"Safety gate: '{self.symbol}' is not recognised as XAUUSD/GOLD")
        if self.timeframe_name not in self.TIMEFRAMES:
            raise ValueError(f"Unsupported timeframe: {self.timeframe_name}")
        try:
            import MetaTrader5 as mt5
        except ImportError as exc:
            raise RuntimeError("MetaTrader5 package missing. Use Windows with MetaTrader 5 installed, then: pip install MetaTrader5") from exc
        self.mt5 = mt5
        init_kwargs = {"path": self.terminal_path} if self.terminal_path else {}
        if not mt5.initialize(**init_kwargs):
            raise RuntimeError(f"MT5 initialize failed: {mt5.last_error()}. Open MT5 and log into your broker's DEMO account.")
        self.assert_demo_account()
        if not mt5.symbol_select(self.symbol, True):
            self.shutdown()
            raise RuntimeError(f"Could not select symbol {self.symbol!r}: {mt5.last_error()}. Check your broker's gold symbol name.")
        info = mt5.symbol_info(self.symbol)
        if info is None:
            self.shutdown()
            raise RuntimeError(f"No MT5 symbol information for {self.symbol!r}")
        print(f"Connected to MT5 DEMO | server={mt5.account_info().server} | login={mt5.account_info().login} | symbol={self.symbol}")

    def assert_demo_account(self) -> None:
        if self.mt5 is None:
            raise SafetyStop("MT5 is not connected")
        account = self.mt5.account_info()
        if account is None:
            raise SafetyStop(f"Cannot verify account type: {self.mt5.last_error()}")
        demo_mode = getattr(self.mt5, "ACCOUNT_TRADE_MODE_DEMO", 0)
        if int(account.trade_mode) != int(demo_mode):
            raise SafetyStop("BLOCKED: connected MT5 account is not a DEMO account. No orders were sent.")
        terminal = self.mt5.terminal_info()
        if terminal is None or not bool(terminal.connected):
            raise SafetyStop("BLOCKED: MT5 terminal is not connected")
        if not bool(terminal.trade_allowed):
            raise SafetyStop("BLOCKED: MT5 terminal has algorithmic trading disabled")

    def timeframe(self, timeframe_name: str | None = None):
        if self.mt5 is None:
            raise RuntimeError("MT5 is not connected")
        name = (timeframe_name or self.timeframe_name).upper()
        if name not in self.TIMEFRAMES:
            raise ValueError(f"Unsupported timeframe: {name}")
        return getattr(self.mt5, self.TIMEFRAMES[name])

    def account_info(self):
        self.assert_demo_account()
        account = self.mt5.account_info()
        if account is None:
            raise RuntimeError(f"Cannot get account info: {self.mt5.last_error()}")
        return account

    def symbol_info(self):
        info = self.mt5.symbol_info(self.symbol)
        if info is None:
            raise RuntimeError(f"Cannot get symbol info for {self.symbol}: {self.mt5.last_error()}")
        return info

    def tick(self):
        tick = self.mt5.symbol_info_tick(self.symbol)
        if tick is None:
            raise RuntimeError(f"Cannot get latest tick for {self.symbol}: {self.mt5.last_error()}")
        return tick

    def closed_bars(self, count: int = 300, timeframe_name: str | None = None) -> pd.DataFrame:
        tf_name = (timeframe_name or self.timeframe_name).upper()
        raw = self.mt5.copy_rates_from_pos(self.symbol, self.timeframe(tf_name), 0, count + 2)
        if raw is None or len(raw) < 3:
            raise RuntimeError(f"Cannot get enough {tf_name} bars for {self.symbol}: {self.mt5.last_error()}")
        df = pd.DataFrame(raw)
        df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
        df.columns = [str(c).lower() for c in df.columns]
        # MT5 returns the copied array oldest-first in physical memory. Sort defensively,
        # then exclude the newest/currently forming candle to avoid repaint/lookahead.
        df = df.sort_values("time").reset_index(drop=True)
        return df.iloc[:-1].tail(count).reset_index(drop=True)

    def open_positions(self):
        positions = self.mt5.positions_get(symbol=self.symbol)
        if positions is None:
            raise RuntimeError(f"Cannot query open positions: {self.mt5.last_error()}")
        return list(positions)

    def history_deals(self, days: int = 90):
        """Read recent MT5 deal history for local learning; never submits orders."""
        from datetime import datetime, timedelta, timezone
        start = datetime.now(timezone.utc) - timedelta(days=max(1, days))
        end = datetime.now(timezone.utc)
        deals = self.mt5.history_deals_get(start, end)
        if deals is None:
            raise RuntimeError(f"Cannot query MT5 deal history: {self.mt5.last_error()}")
        return list(deals)

    def choose_filling_mode(self, symbol_info) -> int:
        mt5 = self.mt5
        flags = int(getattr(symbol_info, "filling_mode", 0))
        if flags & int(getattr(mt5, "SYMBOL_FILLING_IOC", 2)):
            return mt5.ORDER_FILLING_IOC
        if flags & int(getattr(mt5, "SYMBOL_FILLING_FOK", 1)):
            return mt5.ORDER_FILLING_FOK
        return mt5.ORDER_FILLING_RETURN

    def place_market_order(self, side: int, volume: float, stop_loss: float, take_profit: float, deviation_points: int, magic: int):
        """Send a market order only after re-checking the account is DEMO."""
        self.assert_demo_account()  # Re-check immediately before every order submission.
        if side not in (-1, 1) or volume <= 0:
            raise ValueError("Invalid order side or volume")
        info = self.symbol_info()
        tick = self.tick()
        spread = float(tick.ask) - float(tick.bid)
        if not (spread >= 0):
            raise SafetyStop("Invalid quote; order blocked")
        digits = int(info.digits)
        price = float(tick.ask if side == 1 else tick.bid)
        sl = round(float(stop_loss), digits)
        tp = round(float(take_profit), digits)
        price = round(price, digits)
        minimum_stop = float(getattr(info, "trade_stops_level", 0)) * float(info.point)
        if side == 1 and (sl >= price or tp <= price):
            raise SafetyStop("Invalid BUY stop-loss/take-profit geometry; order blocked")
        if side == -1 and (sl <= price or tp >= price):
            raise SafetyStop("Invalid SELL stop-loss/take-profit geometry; order blocked")
        if minimum_stop > 0 and (abs(price - sl) < minimum_stop or abs(tp - price) < minimum_stop):
            raise SafetyStop(f"Stops are inside broker minimum distance ({minimum_stop:g}); order blocked")

        request = {
            "action": self.mt5.TRADE_ACTION_DEAL,
            "symbol": self.symbol,
            "volume": float(volume),
            "type": self.mt5.ORDER_TYPE_BUY if side == 1 else self.mt5.ORDER_TYPE_SELL,
            "price": price,
            "sl": sl,
            "tp": tp,
            "deviation": int(deviation_points),
            "magic": int(magic),
            "comment": "XAU Demo Lab",
            "type_time": self.mt5.ORDER_TIME_GTC,
            "type_filling": self.choose_filling_mode(info),
        }
        check = self.mt5.order_check(request)
        if check is None:
            raise RuntimeError(f"MT5 order_check returned no result: {self.mt5.last_error()}")
        accepted_check_codes = {0, int(getattr(self.mt5, "TRADE_RETCODE_DONE", 10009)), int(getattr(self.mt5, "TRADE_RETCODE_PLACED", 10008))}
        if int(check.retcode) not in accepted_check_codes:
            raise RuntimeError(f"MT5 rejected order check: retcode={check.retcode} comment={getattr(check, 'comment', '')}")

        self.assert_demo_account()  # Second check, right before the actual submit.
        result = self.mt5.order_send(request)
        if result is None:
            raise RuntimeError(f"MT5 order_send returned no result: {self.mt5.last_error()}")
        success_codes = {int(getattr(self.mt5, "TRADE_RETCODE_DONE", 10009)), int(getattr(self.mt5, "TRADE_RETCODE_PLACED", 10008))}
        if int(result.retcode) not in success_codes:
            raise RuntimeError(f"MT5 order failed: retcode={result.retcode} comment={getattr(result, 'comment', '')}")
        return result

    def export_closed_bars(self, count: int, output: str | Path, timeframe_name: str | None = None) -> Path:
        df = self.closed_bars(count, timeframe_name=timeframe_name)
        path = Path(output)
        path.parent.mkdir(parents=True, exist_ok=True)
        keep = [c for c in ["time", "open", "high", "low", "close", "tick_volume", "spread", "real_volume"] if c in df.columns]
        df[keep].to_csv(path, index=False)
        return path

    def shutdown(self) -> None:
        if self.mt5 is not None:
            try:
                self.mt5.shutdown()
            finally:
                self.mt5 = None
