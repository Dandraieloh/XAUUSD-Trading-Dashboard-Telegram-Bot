from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

log = logging.getLogger(__name__)


def research_market(max_results: int = 3) -> dict[str, Any]:
    """Best-effort public-web research through DDGS; no separate search API key.

    Public search endpoints can change or rate-limit. A search failure never bypasses
    safety checks and is returned as research metadata instead of crashing the runner.
    """
    if max_results < 1:
        return {"queried_at": datetime.now(timezone.utc).isoformat(), "items": [], "status": "disabled"}
    query = "XAUUSD gold market latest US dollar Treasury yields Federal Reserve inflation news"
    try:
        from ddgs import DDGS

        with DDGS() as search_client:
            rows = search_client.text(query, max_results=max_results, safesearch="moderate")
        items = []
        for row in rows or []:
            items.append({
                "title": str(row.get("title", ""))[:240],
                "url": str(row.get("href", row.get("url", "")))[:600],
                "published": str(row.get("date", row.get("published", "")))[:80],
                "snippet": str(row.get("body", row.get("snippet", "")))[:700],
            })
        return {
            "queried_at": datetime.now(timezone.utc).isoformat(),
            "query": query,
            "items": items[:max_results],
            "status": "ok" if items else "empty",
        }
    except Exception as exc:  # best-effort by design: external research cannot crash the safety loop
        log.warning("Public market research unavailable (%s). Continuing with price-only evidence.", type(exc).__name__)
        return {
            "queried_at": datetime.now(timezone.utc).isoformat(),
            "query": query,
            "items": [],
            "status": "unavailable",
            "error_type": type(exc).__name__,
        }
