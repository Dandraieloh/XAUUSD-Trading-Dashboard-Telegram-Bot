from __future__ import annotations

import math
from typing import Any

import pandas as pd

from .smc import SMCConfig, analyse_smc

_TIMEFRAME_MINUTES = {"M1": 1, "M5": 5, "M15": 15, "M30": 30, "H1": 60, "H4": 240, "D1": 1440}


def _with_utc_time(frame: pd.DataFrame) -> pd.DataFrame:
    out = frame.copy()
    if "time" not in out.columns:
        raise ValueError("SMC backtest requires a real time column for leakage-safe higher-timeframe alignment")
    out["time"] = pd.to_datetime(out["time"], utc=True, errors="coerce")
    if out["time"].isna().any():
        raise ValueError("SMC backtest found invalid timestamps")
    out = out.sort_values("time").drop_duplicates("time").reset_index(drop=True)
    return out


def run_smc_backtest(
    candles: pd.DataFrame,
    higher_timeframes: dict[str, pd.DataFrame] | None = None,
    execution_timeframe: str = "M5",
    config: SMCConfig | None = None,
    initial_equity: float = 10_000.0,
    risk_pct: float = 0.25,
    contract_units_per_lot: float = 100.0,
    assumed_spread_price: float = 0.30,
    slippage_price_per_side: float = 0.05,
    volume_step: float = 0.01,
    min_volume: float = 0.01,
    max_volume: float = 1.0,
    stop_atr_multiple: float = 1.5,
    reward_risk: float = 2.0,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Causal, rule-only SMC backtest. Claude is intentionally excluded.

    Each signal is calculated from the execution candles available at that time.
    Higher-timeframe bars are included only when their full close time is no later
    than the signal candle's close time. Entry is at the next bar open. Ambiguous
    same-bar SL/TP touches resolve to the stop first.
    """
    tf = execution_timeframe.upper()
    if tf not in _TIMEFRAME_MINUTES:
        raise ValueError(f"Unsupported execution timeframe: {execution_timeframe}")
    if initial_equity <= 0 or not 0 < risk_pct <= 1:
        raise ValueError("initial_equity must be positive and risk_pct must be in (0, 1]")
    if contract_units_per_lot <= 0 or assumed_spread_price < 0 or slippage_price_per_side < 0:
        raise ValueError("Contract units must be positive and costs non-negative")
    if volume_step <= 0 or min_volume <= 0 or max_volume < min_volume:
        raise ValueError("Invalid volume constraints")
    if stop_atr_multiple <= 0 or reward_risk <= 0:
        raise ValueError("Stop multiple and reward/risk must be positive")

    df = _with_utc_time(candles)
    htf: dict[str, pd.DataFrame] = {}
    for name, raw in (higher_timeframes or {}).items():
        name = name.upper()
        if name not in _TIMEFRAME_MINUTES:
            continue
        htf[name] = _with_utc_time(raw)

    cfg = config or SMCConfig()
    equity = float(initial_equity)
    peak = equity
    max_dd = 0.0
    position: dict[str, Any] | None = None
    trades: list[dict[str, Any]] = []
    exec_delta = pd.Timedelta(minutes=_TIMEFRAME_MINUTES[tf])
    warmup = max(60, cfg.atr_period + cfg.swing_length * 2 + 5)

    def close_position(i: int, reference: float, reason: str) -> None:
        nonlocal position, equity, peak, max_dd
        assert position is not None
        side = int(position["side"])
        exit_fill = reference - side * (assumed_spread_price / 2 + slippage_price_per_side)
        pnl = side * (exit_fill - float(position["entry_fill"])) * contract_units_per_lot * float(position["volume"])
        equity += pnl
        peak = max(peak, equity)
        dd = (peak - equity) / peak * 100 if peak > 0 else 100.0
        max_dd = max(max_dd, dd)
        trades.append({
            "entry_time": str(position["entry_time"]), "side": "BUY" if side == 1 else "SELL",
            "volume": float(position["volume"]), "entry_price": round(float(position["entry_fill"]), 5),
            "stop_loss": round(float(position["sl"]), 5), "take_profit": round(float(position["tp"]), 5),
            "exit_time": str(df.iloc[i]["time"]), "exit_price": round(float(exit_fill), 5),
            "exit_reason": reason, "setup_key": position["setup_key"], "pnl": round(pnl, 2),
            "equity_after": round(equity, 2),
        })
        position = None

    for i in range(warmup, len(df)):
        bar = df.iloc[i]
        if position is not None:
            side = int(position["side"])
            hit_sl = float(bar["low"]) <= position["sl"] if side == 1 else float(bar["high"]) >= position["sl"]
            hit_tp = float(bar["high"]) >= position["tp"] if side == 1 else float(bar["low"]) <= position["tp"]
            if hit_sl:
                close_position(i, float(position["sl"]), "SL_BOTH_LEVELS_TOUCHED" if hit_tp else "SL")
            elif hit_tp:
                close_position(i, float(position["tp"]), "TP")
            continue

        signal_time = pd.Timestamp(df.iloc[i - 1]["time"])
        signal_cutoff = signal_time + exec_delta
        available_htf: dict[str, pd.DataFrame] = {}
        for name, htf_frame in htf.items():
            delta = pd.Timedelta(minutes=_TIMEFRAME_MINUTES[name])
            # Candle timestamps are candle-open times; never use an HTF candle before it closes.
            available = htf_frame.loc[htf_frame["time"] + delta <= signal_cutoff]
            if len(available) >= 55:
                available_htf[name] = available
        # Do not create a candidate if any supplied HTF stream is not yet sufficiently warm.
        if htf and len(available_htf) != len(htf):
            continue
        snapshot = analyse_smc(df.iloc[:i].copy(), available_htf, cfg)
        side_text = str(snapshot.get("setup_candidate", "HOLD"))
        atr = float(snapshot.get("atr") or 0.0)
        if side_text not in {"BUY", "SELL"} or not math.isfinite(atr) or atr <= 0:
            continue
        side = 1 if side_text == "BUY" else -1
        entry_reference = float(bar["open"])
        stop_distance = atr * stop_atr_multiple
        risk_cash = equity * risk_pct / 100.0
        per_lot_risk = (stop_distance + assumed_spread_price + 2 * slippage_price_per_side) * contract_units_per_lot
        raw_volume = min(risk_cash / per_lot_risk, max_volume)
        volume = round(math.floor((raw_volume + 1e-12) / volume_step) * volume_step, 8)
        if volume < min_volume or volume * per_lot_risk > risk_cash + 1e-6:
            continue
        entry_fill = entry_reference + side * (assumed_spread_price / 2 + slippage_price_per_side)
        position = {
            "side": side, "entry_time": bar["time"], "entry_fill": entry_fill,
            "sl": entry_reference - side * stop_distance,
            "tp": entry_reference + side * stop_distance * reward_risk,
            "volume": volume, "setup_key": str(snapshot.get("setup_key", "UNKNOWN")),
        }
        hit_sl = float(bar["low"]) <= position["sl"] if side == 1 else float(bar["high"]) >= position["sl"]
        hit_tp = float(bar["high"]) >= position["tp"] if side == 1 else float(bar["low"]) <= position["tp"]
        if hit_sl:
            close_position(i, float(position["sl"]), "SL_BOTH_LEVELS_TOUCHED" if hit_tp else "SL")
        elif hit_tp:
            close_position(i, float(position["tp"]), "TP")

    if position is not None:
        close_position(len(df) - 1, float(df.iloc[-1]["close"]), "END_OF_DATA")

    trades_df = pd.DataFrame.from_records(trades)
    pnl = trades_df["pnl"] if not trades_df.empty else pd.Series(dtype=float)
    wins, losses = pnl[pnl > 0], pnl[pnl < 0]
    gross_profit, gross_loss = float(wins.sum()), float(-losses.sum())
    summary = {
        "strategy": "causal_smc_rules_only_no_llm",
        "initial_equity": round(initial_equity, 2), "ending_equity": round(equity, 2),
        "net_pnl": round(equity - initial_equity, 2),
        "return_pct": round((equity / initial_equity - 1) * 100, 3),
        "closed_trades": int(len(trades_df)),
        "win_rate_pct": round(float((pnl > 0).mean() * 100), 2) if len(pnl) else 0.0,
        "profit_factor": round(gross_profit / gross_loss, 3) if gross_loss else (None if gross_profit == 0 else "infinite"),
        "max_closed_trade_drawdown_pct": round(max_dd, 3),
        "gross_profit": round(gross_profit, 2), "gross_loss": round(gross_loss, 2),
        "assumptions": {
            "execution_timeframe": tf, "risk_per_trade_pct": risk_pct,
            "contract_units_per_lot": contract_units_per_lot, "spread_price": assumed_spread_price,
            "slippage_per_side": slippage_price_per_side, "stop_atr_multiple": stop_atr_multiple,
            "reward_risk": reward_risk, "entry": "next bar open after signal candle",
            "ambiguous_bar": "stop assumed first", "higher_timeframe": "only fully closed bars included",
            "llm": "excluded; this validates technical candidate logic only, not Claude approval or live execution",
        },
    }
    return trades_df, summary
