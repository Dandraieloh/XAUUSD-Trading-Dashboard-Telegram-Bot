from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


def _json(value: Any) -> str:
    return json.dumps(value, separators=(",", ":"), default=str)


class LearningMemory:
    """Persistent experience store for scans, trade outcomes, and setup-family fitness.

    This is bounded adaptation, not online retraining of Claude: prior outcomes alter
    future context and can pause a demonstrably weak setup family, while risk limits
    remain fixed and successful setups never auto-increase risk.
    """

    def __init__(self, path: str | Path = "state/learning.sqlite3", min_setup_sample: int = 8):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.min_setup_sample = max(3, int(min_setup_sample))
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        con = sqlite3.connect(self.path, timeout=10)
        con.row_factory = sqlite3.Row
        return con

    def _initialize(self) -> None:
        with self._connect() as con:
            con.executescript(
                """
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS scans (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    setup_key TEXT NOT NULL,
                    candidate TEXT NOT NULL,
                    ai_action TEXT NOT NULL,
                    approved INTEGER NOT NULL,
                    confidence REAL NOT NULL,
                    market_json TEXT NOT NULL,
                    decision_json TEXT NOT NULL,
                    research_json TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS tracked_positions (
                    position_id INTEGER PRIMARY KEY,
                    symbol TEXT NOT NULL,
                    setup_key TEXT NOT NULL,
                    side TEXT NOT NULL,
                    opened_at TEXT NOT NULL,
                    market_json TEXT NOT NULL,
                    order_ticket INTEGER
                );
                CREATE TABLE IF NOT EXISTS trade_outcomes (
                    position_id INTEGER PRIMARY KEY,
                    close_time TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    setup_key TEXT NOT NULL,
                    side TEXT NOT NULL,
                    pnl REAL NOT NULL,
                    win INTEGER NOT NULL,
                    outcome_json TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_outcomes_setup_time ON trade_outcomes(setup_key, close_time DESC);
                CREATE TABLE IF NOT EXISTS api_usage (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    model TEXT NOT NULL,
                    input_tokens INTEGER NOT NULL,
                    output_tokens INTEGER NOT NULL,
                    estimated_usd REAL NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_api_usage_timestamp ON api_usage(timestamp);
                """
            )

    def record_scan(self, symbol: str, market: dict[str, Any], decision: dict[str, Any], research: dict[str, Any]) -> None:
        stamp = str(market.get("timestamp") or datetime.now(timezone.utc).isoformat())
        with self._connect() as con:
            con.execute(
                """INSERT INTO scans(timestamp,symbol,setup_key,candidate,ai_action,approved,confidence,market_json,decision_json,research_json)
                   VALUES(?,?,?,?,?,?,?,?,?,?)""",
                (
                    stamp, symbol, str(market.get("setup_key", "NO_SETUP")),
                    str(market.get("setup_candidate", "HOLD")), str(decision.get("final_action", "HOLD")),
                    int(bool(decision.get("approved_by_policy", False))), float(decision.get("confidence", 0.0)),
                    _json(market), _json(decision), _json(research),
                ),
            )

    def register_position(
        self,
        position_id: int,
        symbol: str,
        setup_key: str,
        side: str,
        market: dict[str, Any],
        order_ticket: int | None = None,
    ) -> None:
        if position_id <= 0:
            return
        with self._connect() as con:
            con.execute(
                """INSERT OR IGNORE INTO tracked_positions(position_id,symbol,setup_key,side,opened_at,market_json,order_ticket)
                   VALUES(?,?,?,?,?,?,?)""",
                (int(position_id), symbol, setup_key, side, datetime.now(timezone.utc).isoformat(), _json(market), order_ticket),
            )

    def sync_closed_deals(self, deals: Iterable[Any], open_position_ids: set[int]) -> int:
        """Reconcile MT5 exit deals into once-per-position outcomes; duplicate closes are ignored."""
        deal_list = list(deals or [])
        grouped: dict[int, list[Any]] = {}
        for deal in deal_list:
            try:
                position_id = int(getattr(deal, "position_id", 0) or 0)
                entry = int(getattr(deal, "entry", 0))
                ticket = int(getattr(deal, "ticket", 0) or 0)
                if position_id <= 0 or ticket <= 0 or entry == 0:
                    continue  # entry-only deal; not evidence of a closed position
                grouped.setdefault(position_id, []).append(deal)
            except (TypeError, ValueError):
                continue

        recorded = 0
        with self._connect() as con:
            tracked = {int(r["position_id"]): r for r in con.execute("SELECT * FROM tracked_positions").fetchall()}
            existing = {int(r[0]) for r in con.execute("SELECT position_id FROM trade_outcomes").fetchall()}
            for position_id, exits in grouped.items():
                if position_id in open_position_ids or position_id in existing or position_id not in tracked:
                    continue
                # Include all deals for the position present in the lookback so entry commission
                # and swap are counted where the broker's history response contains them.
                all_for_position = [d for d in deal_list if int(getattr(d, "position_id", 0) or 0) == position_id]
                total_pnl = sum(
                    float(getattr(d, "profit", 0.0) or 0.0)
                    + float(getattr(d, "commission", 0.0) or 0.0)
                    + float(getattr(d, "swap", 0.0) or 0.0)
                    + float(getattr(d, "fee", 0.0) or 0.0)
                    for d in all_for_position
                )
                latest = max(exits, key=lambda d: int(getattr(d, "time", 0) or 0))
                close_seconds = int(getattr(latest, "time", 0) or 0)
                close_time = datetime.fromtimestamp(close_seconds, timezone.utc).isoformat() if close_seconds else datetime.now(timezone.utc).isoformat()
                row = tracked[position_id]
                details = {
                    "position_id": position_id,
                    "exit_deal_tickets": [int(getattr(d, "ticket", 0) or 0) for d in exits],
                    "closed_deal_count": len(exits),
                    "net_pnl": total_pnl,
                    "interpretation": "One broker position; P&L includes deal profit, commission, swap and fee available in MT5 history.",
                }
                con.execute(
                    """INSERT OR IGNORE INTO trade_outcomes(position_id,close_time,symbol,setup_key,side,pnl,win,outcome_json)
                       VALUES(?,?,?,?,?,?,?,?)""",
                    (position_id, close_time, row["symbol"], row["setup_key"], row["side"], total_pnl, int(total_pnl > 0), _json(details)),
                )
                if con.execute("SELECT changes()").fetchone()[0]:
                    recorded += 1
        return recorded

    def recent_lessons(self, limit: int = 12) -> list[dict[str, Any]]:
        requested = max(1, min(30, int(limit)))
        outcome_limit = max(1, requested * 2 // 3)
        fitness_limit = max(0, requested - outcome_limit)
        with self._connect() as con:
            outcomes = con.execute(
                """SELECT o.close_time,o.setup_key,o.side,o.pnl,o.win,t.market_json
                   FROM trade_outcomes AS o LEFT JOIN tracked_positions AS t ON t.position_id=o.position_id
                   ORDER BY o.close_time DESC LIMIT ?""",
                (outcome_limit,),
            ).fetchall()
            setup_rows = con.execute(
                """SELECT setup_key,COUNT(*) AS n,SUM(pnl) AS pnl_sum,AVG(win) AS win_rate,AVG(pnl) AS avg_pnl
                   FROM trade_outcomes GROUP BY setup_key ORDER BY COUNT(*) DESC LIMIT ?""",
                (fitness_limit,),
            ).fetchall() if fitness_limit else []
        recent_trade_lessons: list[dict[str, Any]] = []
        for row in outcomes:
            try:
                snapshot = json.loads(row["market_json"] or "{}")
            except (json.JSONDecodeError, TypeError):
                snapshot = {}
            orchestrator_record = snapshot.get("orchestrator_record", {}) if isinstance(snapshot, dict) else {}
            recent_trade_lessons.append({
                "kind": "closed_trade",
                "closed_at": row["close_time"],
                "setup_family": row["setup_key"],
                "side": row["side"],
                "net_pnl": round(float(row["pnl"]), 2),
                "result": "WIN" if row["win"] else "LOSS_OR_FLAT",
                "entry_thesis": str(orchestrator_record.get("thesis", ""))[:300],
                "entry_structure": snapshot.get("structure_event"),
                "entry_trend": (snapshot.get("trend") or {}).get("direction") if isinstance(snapshot.get("trend"), dict) else None,
                "entry_research_status": orchestrator_record.get("research_status"),
            })
        fitness_lessons: list[dict[str, Any]] = []
        for row in setup_rows:
            n = int(row["n"])
            enough = n >= self.min_setup_sample
            pnl_sum = float(row["pnl_sum"] or 0.0)
            win_rate = float(row["win_rate"] or 0.0)
            status = "PAUSE_WEAK_FAMILY" if enough and (pnl_sum <= 0 or win_rate < 0.35) else "WATCH" if enough else "INSUFFICIENT_SAMPLE"
            fitness_lessons.append({
                "kind": "setup_family_fitness",
                "setup_family": row["setup_key"],
                "closed_trades": n,
                "net_pnl": round(pnl_sum, 2),
                "win_rate": round(win_rate, 3),
                "mean_trade_pnl": round(float(row["avg_pnl"] or 0.0), 2),
                "status": status,
            })
        return recent_trade_lessons + fitness_lessons

    def setup_is_paused(self, setup_key: str) -> tuple[bool, str]:
        with self._connect() as con:
            row = con.execute(
                "SELECT COUNT(*) AS n,SUM(pnl) AS pnl_sum,AVG(win) AS win_rate FROM trade_outcomes WHERE setup_key=?",
                (setup_key,),
            ).fetchone()
        n = int(row["n"] or 0)
        pnl_sum = float(row["pnl_sum"] or 0.0)
        win_rate = float(row["win_rate"] or 0.0)
        paused = n >= self.min_setup_sample and (pnl_sum <= 0 or win_rate < 0.35)
        if paused:
            return True, f"setup family paused after {n} closed trades (net={pnl_sum:.2f}, win_rate={win_rate:.0%})"
        return False, f"setup family active/watch (n={n}, net={pnl_sum:.2f}, win_rate={win_rate:.0%})"

    def estimated_api_spend_today(self, now: datetime | None = None) -> float:
        now = now or datetime.now(timezone.utc)
        today = now.astimezone(timezone.utc).date().isoformat()
        with self._connect() as con:
            row = con.execute("SELECT COALESCE(SUM(estimated_usd),0) AS spend FROM api_usage WHERE substr(timestamp,1,10)=?", (today,)).fetchone()
        return float(row["spend"] or 0.0)

    def can_call_llm(self, daily_budget_usd: float) -> tuple[bool, str]:
        if daily_budget_usd <= 0:
            return False, "Claude call budget is set to zero; no API call will be made"
        spent = self.estimated_api_spend_today()
        if spent >= daily_budget_usd:
            return False, f"Estimated Claude API spend reached daily cap (${spent:.4f} / ${daily_budget_usd:.2f} UTC)"
        return True, f"Estimated Claude API spend today: ${spent:.4f} / ${daily_budget_usd:.2f} UTC"

    def record_api_usage(
        self, model: str, input_tokens: int, output_tokens: int,
        input_usd_per_mtok: float = 3.0, output_usd_per_mtok: float = 15.0,
    ) -> float:
        input_tokens = max(0, int(input_tokens))
        output_tokens = max(0, int(output_tokens))
        cost = input_tokens * input_usd_per_mtok / 1_000_000 + output_tokens * output_usd_per_mtok / 1_000_000
        with self._connect() as con:
            con.execute(
                "INSERT INTO api_usage(timestamp,model,input_tokens,output_tokens,estimated_usd) VALUES(?,?,?,?,?)",
                (datetime.now(timezone.utc).isoformat(), model, input_tokens, output_tokens, cost),
            )
        return cost

    def summary(self) -> dict[str, Any]:
        with self._connect() as con:
            scans = int(con.execute("SELECT COUNT(*) FROM scans").fetchone()[0])
            total = int(con.execute("SELECT COUNT(*) FROM trade_outcomes").fetchone()[0])
            net = float(con.execute("SELECT COALESCE(SUM(pnl),0) FROM trade_outcomes").fetchone()[0])
            wins = int(con.execute("SELECT COALESCE(SUM(win),0) FROM trade_outcomes").fetchone()[0])
            api_spend_today = float(con.execute("SELECT COALESCE(SUM(estimated_usd),0) FROM api_usage WHERE substr(timestamp,1,10)=?", (datetime.now(timezone.utc).date().isoformat(),)).fetchone()[0])
        return {"scans": scans, "closed_positions": total, "net_pnl": round(net, 2), "win_rate": round(wins / total, 3) if total else None, "min_setup_sample": self.min_setup_sample, "estimated_api_spend_today_usd": round(api_spend_today, 4)}
