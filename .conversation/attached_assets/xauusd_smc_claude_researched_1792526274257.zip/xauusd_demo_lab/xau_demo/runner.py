from __future__ import annotations

import logging
import os
import time
from pathlib import Path
from typing import Any

from .config import AppConfig
from .memory import LearningMemory
from .mt5_adapter import MT5Adapter, SafetyStop
from .orchestrator import ClaudeOrchestrator, OrchestratorConfig
from .research import research_market
from .risk import DailyLossGuard, calculate_volume
from .smc import SMCConfig, analyse_smc

log = logging.getLogger(__name__)


def _open_position_ids(positions: list[Any]) -> set[int]:
    ids: set[int] = set()
    for position in positions:
        for key in ("identifier", "ticket"):
            try:
                val = int(getattr(position, key, 0) or 0)
                if val > 0:
                    ids.add(val)
            except (TypeError, ValueError):
                pass
    return ids


def _decision_error(exc: Exception, model: str) -> dict[str, Any]:
    # No raw request/configuration payload or API key is logged.
    return {
        "action": "HOLD", "final_action": "HOLD", "approve": False,
        "approved_by_policy": False, "confidence": 0.0,
        "thesis": f"Orchestrator unavailable; fail-closed ({type(exc).__name__}).",
        "reasons": ["Claude review did not complete"], "risk_flags": ["ORCHESTRATOR_UNAVAILABLE"],
        "invalidation": "No order until a valid Claude decision is available.",
        "research_impact": "Not assessed", "model": model,
    }


def run_demo(config: AppConfig, state_path: str | Path = "state/daily_guard.json") -> None:
    """Run SMC + trend + Claude orchestration; execution is strictly MT5-demo only."""
    # Build the LLM client before initializing a broker session, so missing credentials
    # fail without touching a terminal. API-key strings are never printed or persisted.
    orchestrator = None
    if config.anthropic_daily_budget_usd > 0:
        orchestrator = ClaudeOrchestrator(
            OrchestratorConfig(
                api_key=os.getenv("ANTHROPIC_API_KEY"),
                model=config.anthropic_model,
                confidence_threshold=config.confidence_threshold,
                max_tokens=int(os.getenv("ANTHROPIC_MAX_TOKENS", "650")),
            )
        )
    memory = LearningMemory(config.learning_db_path, config.learning_min_setup_sample)
    adapter = MT5Adapter(config.symbol, config.timeframe_name)
    guard = DailyLossGuard(state_path, config.risk.daily_loss_limit_pct)
    smc_config = SMCConfig(config.smc_swing_length, config.smc_event_lookback, config.atr_period_smc)
    try:
        adapter.connect_demo()
        account = adapter.account_info()
        can_trade, message = guard.can_open_new_trade(float(account.equity))
        print(f"Connected to DEMO | equity={account.equity:.2f} {account.currency} | {message}")
        print(f"Orchestrator={config.anthropic_model} | HTF={','.join(config.htf_timeframes)} | research={'on' if config.research_enabled else 'off'}")
        print(f"Learning DB={config.learning_db_path} | current memory={memory.summary()}")

        bars = adapter.closed_bars(config.bars_required)
        last_processed_time = bars.iloc[-1]["time"]
        print(f"Waiting for the next completed {config.timeframe_name} candle; latest closed bar={last_processed_time} UTC")
        while True:
            time.sleep(config.poll_seconds)
            adapter.assert_demo_account()
            bars = adapter.closed_bars(config.bars_required)
            latest_time = bars.iloc[-1]["time"]
            if latest_time == last_processed_time:
                continue
            last_processed_time = latest_time
            stamp = str(latest_time)

            # Reconcile closed positions first so the just-completed outcome can influence
            # this candle's decision context. A history outage cannot relax any guard.
            positions = adapter.open_positions()
            try:
                deals = adapter.history_deals(days=90)
                learnt = memory.sync_closed_deals(deals, _open_position_ids(positions))
                if learnt:
                    print(f"{stamp} | Learning memory recorded {learnt} closed position(s) | {memory.summary()}")
            except Exception as exc:
                log.warning("Could not reconcile trade outcomes (%s); continuing with prior memory only.", type(exc).__name__)

            htf_candles: dict[str, Any] = {}
            for tf in config.htf_timeframes:
                try:
                    htf_candles[tf] = adapter.closed_bars(max(100, min(config.bars_required, 250)), timeframe_name=tf)
                except Exception as exc:
                    log.warning("Higher-timeframe %s unavailable (%s); analysis will be fail-closed.", tf, type(exc).__name__)
            try:
                market = analyse_smc(bars, htf_candles, smc_config)
                missing_htf = [tf for tf in config.htf_timeframes if tf not in htf_candles or len(htf_candles[tf]) < 55]
                if missing_htf:
                    market["setup_candidate"] = "HOLD"
                    market["setup_key"] = "HOLD|HTF_MISSING|" + ",".join(missing_htf)
                    market["reasons"].append("Required higher-timeframe data missing: " + ", ".join(missing_htf) + "; fail closed")
            except Exception as exc:
                print(f"{stamp} | SMC analysis unavailable ({type(exc).__name__}); no order considered")
                continue
            market["symbol"] = config.symbol
            market["execution_timeframe"] = config.timeframe_name
            market["account_currency"] = str(account.currency)

            research = research_market(config.research_max_results) if config.research_enabled else {
                "status": "disabled", "items": [], "queried_at": stamp,
            }
            lessons = memory.recent_lessons(12)
            budget_ok, budget_message = memory.can_call_llm(config.anthropic_daily_budget_usd)
            if not budget_ok:
                decision = _decision_error(RuntimeError("daily estimated API budget reached"), config.anthropic_model)
                decision["thesis"] = budget_message + "; holding until next UTC day or a larger configured cap."
                print(f"{stamp} | API BUDGET GUARD | {budget_message}")
            else:
                try:
                    if orchestrator is None:
                        raise RuntimeError("Claude orchestrator is disabled by zero daily budget")
                    decision = orchestrator.review(market, research, lessons)
                    usage = decision.get("usage", {})
                    if usage:
                        price = memory.record_api_usage(
                            config.anthropic_model, usage.get("input_tokens", 0), usage.get("output_tokens", 0),
                            config.anthropic_input_usd_per_mtok, config.anthropic_output_usd_per_mtok,
                        )
                        decision["usage"]["estimated_usd"] = round(price, 6)
                except Exception as exc:
                    decision = _decision_error(exc, config.anthropic_model)
                    log.warning("Claude review failed (%s); no order will be sent for this candle.", type(exc).__name__)
            market["research_summary"] = [
                {"title": item.get("title", ""), "published": item.get("published", ""), "url": item.get("url", "")}
                for item in research.get("items", [])[:3]
            ]
            market["orchestrator_record"] = {
                "action": decision.get("final_action", "HOLD"),
                "confidence": decision.get("confidence", 0.0),
                "thesis": decision.get("thesis", ""),
                "reasons": decision.get("reasons", []),
                "research_impact": decision.get("research_impact", ""),
                "research_status": research.get("status", "unknown"),
            }
            memory.record_scan(config.symbol, market, decision, research)

            direction = str(decision.get("final_action", "HOLD")).upper()
            htf_summary = ", ".join(f"{name}:{value['direction']}" for name, value in market["higher_timeframes"].items()) or "unavailable"
            print(
                f"{stamp} | SMC={market['setup_candidate']} | trend={market['trend']['direction']} "
                f"structure={market['structure_event']} sweep={market['recent_liquidity_sweep']} "
                f"HTF={htf_summary} | Claude={direction} confidence={decision.get('confidence', 0):.2f} "
                f"research={research.get('status', 'unknown')}"
            )
            if direction not in {"BUY", "SELL"} or not decision.get("approved_by_policy"):
                note = decision.get("thesis", "No eligible setup; no order considered.")
                print(f"{stamp} | HOLD | {str(note)[:280]}")
                continue
            side = 1 if direction == "BUY" else -1
            setup_key = str(market.get("setup_key", "NO_SETUP"))
            paused, pause_message = memory.setup_is_paused(setup_key)
            if paused:
                print(f"{stamp} | ADAPTIVE LEARNING BLOCK | {pause_message}")
                continue

            # Hard deterministic gates are independent of Claude's opinion.
            account = adapter.account_info()
            can_trade, message = guard.can_open_new_trade(float(account.equity))
            if not can_trade:
                print(f"{stamp} | {message}; no new orders will be opened")
                continue
            current_positions = adapter.open_positions()
            if current_positions:
                print(f"{stamp} | {direction} ignored: {len(current_positions)} position(s) already open on {config.symbol}; bot will not modify them")
                continue
            tick = adapter.tick()
            spread = float(tick.ask) - float(tick.bid)
            if spread < 0 or spread > config.risk.max_spread_price:
                print(f"{stamp} | {direction} ignored: spread={spread:.3f}, allowed<={config.risk.max_spread_price:.3f}")
                continue

            atr = float(market.get("atr", 0.0))
            if not (atr > 0):
                print(f"{stamp} | {direction} ignored: ATR is invalid")
                continue
            info = adapter.symbol_info()
            digits = int(info.digits)
            entry_reference = float(tick.ask if side == 1 else tick.bid)
            atr_stop_distance = atr * config.strategy.atr_stop_multiple
            sweep_detail = market.get("liquidity_sweep_detail") or {}
            sweep_extreme = sweep_detail.get("extreme")
            # Anchor risk beyond the liquidity-sweep extreme, and never make the stop
            # tighter than the ATR baseline. Volume is then sized to this actual distance.
            if side == 1 and sweep_extreme is not None:
                stop_price_reference = min(entry_reference - atr_stop_distance, float(sweep_extreme) - 0.10 * atr)
            elif side == -1 and sweep_extreme is not None:
                stop_price_reference = max(entry_reference + atr_stop_distance, float(sweep_extreme) + 0.10 * atr)
            else:
                stop_price_reference = entry_reference - side * atr_stop_distance
            stop_distance = abs(entry_reference - stop_price_reference)
            volume, estimated_risk = calculate_volume(
                equity=float(account.equity), risk_pct=config.risk.risk_per_trade_pct,
                stop_distance_price=stop_distance, tick_size=float(info.trade_tick_size),
                tick_value=float(info.trade_tick_value),
                volume_min=float(info.volume_min or config.risk.volume_min_fallback),
                volume_max=float(info.volume_max), volume_step=float(info.volume_step or config.risk.volume_step_fallback),
                hard_max_volume=config.risk.max_lots,
            )
            if volume <= 0:
                print(f"{stamp} | {direction} ignored: minimum broker lot would exceed risk budget (equity={account.equity:.2f})")
                continue
            stop_loss = round(stop_price_reference, digits)
            take_profit = round(entry_reference + side * stop_distance * config.strategy.reward_risk, digits)
            try:
                result = adapter.place_market_order(
                    side, volume, stop_loss, take_profit,
                    config.risk.deviation_points, config.risk.magic,
                )
            except SafetyStop as exc:
                print(f"{stamp} | SAFETY BLOCK: {exc}")
                continue
            except Exception as exc:
                print(f"{stamp} | Order was not confirmed: {type(exc).__name__}; verify MT5 terminal before retrying")
                continue

            # Log broker acceptance before touching local memory: a local database failure
            # must never mislabel a confirmed order as unconfirmed and tempt a manual retry.
            order_ticket = int(getattr(result, "order", 0) or 0)
            position_id = order_ticket
            try:
                refreshed_positions = adapter.open_positions()
                if refreshed_positions:
                    chosen = max(refreshed_positions, key=lambda p: int(getattr(p, "time", 0) or 0))
                    candidate_id = int(getattr(chosen, "identifier", 0) or getattr(chosen, "ticket", 0) or 0)
                    if candidate_id > 0:
                        position_id = candidate_id
            except Exception:
                pass
            print(
                f"{stamp} | DEMO ORDER ACCEPTED | {direction} {volume:g} {config.symbol} "
                f"entry~{entry_reference:.{digits}f} SL={stop_loss} TP={take_profit} "
                f"estimated_risk={estimated_risk:.2f} {account.currency} "
                f"position={position_id} order={getattr(result, 'order', '?')} deal={getattr(result, 'deal', '?')}"
            )
            try:
                memory.register_position(position_id, config.symbol, setup_key, direction, market, order_ticket)
            except Exception as exc:
                log.error("Order was accepted by MT5, but local learning memory failed (%s). Inspect the terminal; do not retry the trade.", type(exc).__name__)
                print(f"{stamp} | MEMORY WARNING: order accepted; persistence failed. Inspect MT5 and do not retry this order.")
    except KeyboardInterrupt:
        print("Stopped by user. Any open demo position remains under its broker-side SL/TP; check MT5 directly.")
    finally:
        adapter.shutdown()
