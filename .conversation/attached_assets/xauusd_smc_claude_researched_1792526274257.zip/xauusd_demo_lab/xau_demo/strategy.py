from __future__ import annotations

import numpy as np
import pandas as pd

from .config import StrategyConfig

REQUIRED_COLUMNS = {"open", "high", "low", "close"}


def add_indicators(candles: pd.DataFrame, config: StrategyConfig) -> pd.DataFrame:
    """Return candles with indicators and close-of-bar signals.

    signal = +1 means long, -1 means short, and 0 means no new entry.
    The runner enters on the following bar/tick, never on the signal candle.
    """
    config.validate()
    missing = REQUIRED_COLUMNS.difference(c.lower() for c in candles.columns)
    if missing:
        raise ValueError(f"Candles missing required columns: {sorted(missing)}")

    # Normalise column names while preserving unrelated columns such as time.
    out = candles.copy()
    out.columns = [str(c).lower() for c in out.columns]
    for col in ("open", "high", "low", "close"):
        out[col] = pd.to_numeric(out[col], errors="coerce")
    out = out.dropna(subset=["open", "high", "low", "close"]).reset_index(drop=True)
    if out.empty:
        raise ValueError("No usable candles")
    if (out["high"] < out["low"]).any():
        raise ValueError("Invalid candle: high is below low")

    close = out["close"]
    out["ema_fast"] = close.ewm(span=config.fast_ema, adjust=False, min_periods=config.fast_ema).mean()
    out["ema_slow"] = close.ewm(span=config.slow_ema, adjust=False, min_periods=config.slow_ema).mean()

    change = close.diff()
    gain = change.clip(lower=0).ewm(alpha=1 / config.rsi_period, adjust=False, min_periods=config.rsi_period).mean()
    loss = (-change.clip(upper=0)).ewm(alpha=1 / config.rsi_period, adjust=False, min_periods=config.rsi_period).mean()
    rs = gain / loss.replace(0, np.nan)
    out["rsi"] = 100 - (100 / (1 + rs))
    # Handles a strictly rising run without producing a bogus NaN RSI.
    out.loc[(loss == 0) & (gain > 0), "rsi"] = 100.0
    out.loc[(loss == 0) & (gain == 0), "rsi"] = 50.0

    previous_close = close.shift(1)
    true_range = pd.concat(
        [out["high"] - out["low"], (out["high"] - previous_close).abs(), (out["low"] - previous_close).abs()],
        axis=1,
    ).max(axis=1)
    out["atr"] = true_range.ewm(alpha=1 / config.atr_period, adjust=False, min_periods=config.atr_period).mean()

    cross_up = (out["ema_fast"] > out["ema_slow"]) & (out["ema_fast"].shift(1) <= out["ema_slow"].shift(1))
    cross_down = (out["ema_fast"] < out["ema_slow"]) & (out["ema_fast"].shift(1) >= out["ema_slow"].shift(1))
    long_filter = out["rsi"].between(config.long_rsi_min, config.long_rsi_max, inclusive="both")
    short_filter = out["rsi"].between(config.short_rsi_min, config.short_rsi_max, inclusive="both")

    out["signal"] = 0
    out.loc[cross_up & long_filter & out["atr"].notna(), "signal"] = 1
    out.loc[cross_down & short_filter & out["atr"].notna(), "signal"] = -1
    out["signal"] = out["signal"].astype(int)
    return out
