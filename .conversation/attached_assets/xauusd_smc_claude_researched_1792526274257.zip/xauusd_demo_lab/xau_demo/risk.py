from __future__ import annotations

import json
import math
from datetime import datetime, timezone
from pathlib import Path


def calculate_volume(
    equity: float,
    risk_pct: float,
    stop_distance_price: float,
    tick_size: float,
    tick_value: float,
    volume_min: float,
    volume_max: float,
    volume_step: float,
    hard_max_volume: float,
) -> tuple[float, float]:
    """Size volume using the broker's tick economics; return (volume, estimated risk).

    Returns (0, 0) when the smallest tradable volume breaches the risk budget.
    ``tick_value`` is expected to be the account-currency value for one tick at
    one lot, as reported by the connected broker's MT5 symbol specification.
    """
    values = (equity, risk_pct, stop_distance_price, tick_size, tick_value, volume_min, volume_max, volume_step, hard_max_volume)
    if not all(math.isfinite(float(v)) for v in values):
        raise ValueError("Risk inputs must be finite numbers")
    if equity <= 0 or not 0 < risk_pct <= 1 or stop_distance_price <= 0 or tick_size <= 0 or tick_value <= 0:
        return 0.0, 0.0
    if volume_min <= 0 or volume_max < volume_min or volume_step <= 0 or hard_max_volume <= 0:
        return 0.0, 0.0

    risk_cash = equity * risk_pct / 100.0
    risk_per_lot = (stop_distance_price / tick_size) * tick_value
    if risk_per_lot <= 0 or not math.isfinite(risk_per_lot):
        return 0.0, 0.0
    max_allowed = min(volume_max, hard_max_volume)
    raw = min(risk_cash / risk_per_lot, max_allowed)
    # Round DOWN to the broker's step; never round up into a larger risk.
    steps = math.floor((raw + 1e-12) / volume_step)
    volume = steps * volume_step
    decimals = max(0, min(8, len(f"{volume_step:.8f}".rstrip("0").split(".")[-1])))
    volume = round(volume, decimals)
    if volume + 1e-12 < volume_min:
        return 0.0, 0.0
    estimated_risk = volume * risk_per_lot
    if estimated_risk > risk_cash + 1e-7:
        return 0.0, 0.0
    return volume, estimated_risk


class DailyLossGuard:
    """Persist a UTC-day equity baseline so restarts cannot reset the loss limit."""

    def __init__(self, path: str | Path, loss_limit_pct: float):
        if not 0 < loss_limit_pct <= 5:
            raise ValueError("loss_limit_pct must be > 0 and <= 5")
        self.path = Path(path)
        self.loss_limit_pct = float(loss_limit_pct)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def _read(self) -> dict:
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            return {}

    def can_open_new_trade(self, equity: float, now: datetime | None = None) -> tuple[bool, str]:
        if not math.isfinite(equity) or equity <= 0:
            return False, "Invalid account equity; trading blocked"
        now = now or datetime.now(timezone.utc)
        day = now.astimezone(timezone.utc).date().isoformat()
        state = self._read()
        if state.get("utc_date") != day or not isinstance(state.get("start_equity"), (int, float)):
            state = {"utc_date": day, "start_equity": float(equity), "blocked": False}
            self.path.write_text(json.dumps(state, indent=2), encoding="utf-8")
        start = float(state["start_equity"])
        if start <= 0:
            return False, "Invalid daily baseline; trading blocked"
        drawdown_pct = max(0.0, (start - equity) / start * 100.0)
        if state.get("blocked"):
            return False, f"Daily loss guard remains latched ({drawdown_pct:.2f}% from UTC-day baseline)"
        if drawdown_pct >= self.loss_limit_pct:
            state["blocked"] = True
            self.path.write_text(json.dumps(state, indent=2), encoding="utf-8")
            return False, f"Daily loss guard active ({drawdown_pct:.2f}% from UTC-day baseline)"
        return True, f"Daily loss guard OK ({drawdown_pct:.2f}% from UTC-day baseline)"
