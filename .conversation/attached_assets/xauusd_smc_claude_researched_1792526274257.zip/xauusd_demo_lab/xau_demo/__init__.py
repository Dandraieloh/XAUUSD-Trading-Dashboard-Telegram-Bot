"""XAUUSD Demo Lab: SMC + trend research with a strictly demo-only execution gate."""

__version__ = "0.2.0"
