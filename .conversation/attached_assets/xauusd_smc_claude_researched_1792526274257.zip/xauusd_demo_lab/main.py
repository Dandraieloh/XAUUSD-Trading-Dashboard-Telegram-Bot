from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from dotenv import load_dotenv

from xau_demo.backtest import load_candles_csv, run_backtest, save_backtest_report
from xau_demo.config import AppConfig
from xau_demo.mt5_adapter import MT5Adapter
from xau_demo.runner import run_demo
from xau_demo.memory import LearningMemory
from xau_demo.smc import SMCConfig, analyse_smc
from xau_demo.smc_backtest import run_smc_backtest


def make_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="XAUUSD Demo Lab - research, backtest, and strictly demo-only MT5 execution")
    sub = parser.add_subparsers(dest="command", required=True)

    backtest = sub.add_parser("backtest", help="Backtest an OHLC CSV; this never connects to a broker")
    backtest.add_argument("--csv", required=True, help="CSV with time (optional), open, high, low, close columns")
    backtest.add_argument("--initial-equity", type=float, default=10_000.0)
    backtest.add_argument("--risk-pct", type=float, default=None, help="Risk in percent of equity, e.g. 0.25 means 0.25%%")
    backtest.add_argument("--contract-units", type=float, default=100.0, help="Assumed gold units per 1 lot; broker-specific")
    backtest.add_argument("--spread", type=float, default=0.30, help="Assumed XAUUSD price spread, e.g. 0.30 dollars")
    backtest.add_argument("--slippage", type=float, default=0.05, help="Assumed adverse price movement per side")
    backtest.add_argument("--max-volume", type=float, default=1.0)
    backtest.add_argument("--output-dir", default="reports")

    smc_bt = sub.add_parser("backtest-smc", help="Causal SMC rule-only backtest; does not call Claude or connect to a broker")
    smc_bt.add_argument("--csv", required=True, help="Execution timeframe CSV with real timestamps and OHLC")
    smc_bt.add_argument("--h1-csv", default=None, help="Optional H1 confirmation CSV with real timestamps")
    smc_bt.add_argument("--h4-csv", default=None, help="Optional H4 confirmation CSV with real timestamps")
    smc_bt.add_argument("--timeframe", choices=["M1", "M5", "M15", "M30", "H1", "H4", "D1"], default="M5")
    smc_bt.add_argument("--initial-equity", type=float, default=10000.0)
    smc_bt.add_argument("--risk-pct", type=float, default=None)
    smc_bt.add_argument("--contract-units", type=float, default=100.0)
    smc_bt.add_argument("--spread", type=float, default=0.30)
    smc_bt.add_argument("--slippage", type=float, default=0.05)
    smc_bt.add_argument("--max-volume", type=float, default=1.0)
    smc_bt.add_argument("--output-dir", default="reports/smc")

    export = sub.add_parser("export-bars", help="Export historical closed candles from an MT5 demo terminal")
    export.add_argument("--bars", type=int, default=5000)
    export.add_argument("--output", default="data/XAUUSD_M5.csv")
    export.add_argument("--timeframe", choices=["M1", "M5", "M15", "M30", "H1", "H4", "D1"], default=None,
                        help="Timeframe to export; defaults to MT5_TIMEFRAME from .env")

    inspect = sub.add_parser("analyse-smc", help="Inspect latest SMC/trend snapshot from CSV; never calls Claude or sends orders")
    inspect.add_argument("--csv", required=True, help="Execution-timeframe candles CSV")
    inspect.add_argument("--h1-csv", default=None, help="Optional H1 candles CSV")
    inspect.add_argument("--h4-csv", default=None, help="Optional H4 candles CSV")

    memory_cmd = sub.add_parser("memory-stats", help="Inspect local learning memory and estimated Claude spend")
    memory_cmd.add_argument("--db", default=None, help="Override LEARNING_DB_PATH from .env")
    memory_cmd.add_argument("--recent", type=int, default=12, help="Number of recent outcomes/fitness lessons to show")

    demo = sub.add_parser("demo", help="Run the SMC + Claude strategy with demo MT5 order submission")
    demo.add_argument("--confirm-demo", action="store_true", help="Required acknowledgement; runtime also rejects non-demo accounts")
    demo.add_argument("--state", default="state/daily_guard.json", help="Persisted UTC-day equity baseline for daily loss guard")
    return parser


def main(argv: list[str] | None = None) -> int:
    load_dotenv()
    args = make_parser().parse_args(argv)
    try:
        if args.command == "backtest":
            config = AppConfig.from_env()
            candles = load_candles_csv(args.csv)
            trades, summary = run_backtest(
                candles=candles,
                strategy=config.strategy,
                initial_equity=args.initial_equity,
                risk_pct=args.risk_pct if args.risk_pct is not None else config.risk.risk_per_trade_pct,
                contract_units_per_lot=args.contract_units,
                assumed_spread_price=args.spread,
                slippage_price_per_side=args.slippage,
                max_volume=args.max_volume,
            )
            trades_path, summary_path = save_backtest_report(trades, summary, args.output_dir)
            print(json.dumps(summary, indent=2))
            print(f"\nTrades: {trades_path}\nSummary: {summary_path}")
            print("Research warning: results depend on CSV quality and the explicitly stated spread/slippage/contract assumptions; this is not a forecast.")
            return 0

        if args.command == "backtest-smc":
            config = AppConfig.from_env()
            candles = load_candles_csv(args.csv)
            htf_frames = {}
            if args.h1_csv:
                htf_frames["H1"] = load_candles_csv(args.h1_csv)
            if args.h4_csv:
                htf_frames["H4"] = load_candles_csv(args.h4_csv)
            missing_htf = [tf for tf in config.htf_timeframes if tf not in htf_frames]
            if missing_htf:
                raise ValueError("SMC backtest requires the configured higher-timeframe CSVs: " + ", ".join(missing_htf))
            trades, summary = run_smc_backtest(
                candles=candles, higher_timeframes=htf_frames, execution_timeframe=args.timeframe,
                config=SMCConfig(config.smc_swing_length, config.smc_event_lookback, config.atr_period_smc),
                initial_equity=args.initial_equity,
                risk_pct=args.risk_pct if args.risk_pct is not None else config.risk.risk_per_trade_pct,
                contract_units_per_lot=args.contract_units, assumed_spread_price=args.spread,
                slippage_price_per_side=args.slippage, max_volume=args.max_volume,
                stop_atr_multiple=config.strategy.atr_stop_multiple, reward_risk=config.strategy.reward_risk,
            )
            out = Path(args.output_dir)
            out.mkdir(parents=True, exist_ok=True)
            trades_path, summary_path = out / "smc_trades.csv", out / "smc_summary.json"
            trades.to_csv(trades_path, index=False)
            summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
            print(json.dumps(summary, indent=2))
            print(f"\nTrades: {trades_path}\nSummary: {summary_path}")
            print("Important: this tests causal technical SMC rules only; it does not simulate Claude decisions or validate live profitability.")
            return 0

        if args.command == "export-bars":
            if args.bars < 100:
                raise ValueError("Use at least 100 bars for an indicator-ready dataset")
            config = AppConfig.from_env()
            adapter = MT5Adapter(config.symbol, config.timeframe_name)
            try:
                adapter.connect_demo()
                tf = args.timeframe or config.timeframe_name
                output = adapter.export_closed_bars(args.bars, args.output, timeframe_name=tf)
                print(f"Exported {args.bars} closed {tf} candles to {output}")
            finally:
                adapter.shutdown()
            return 0

        if args.command == "analyse-smc":
            config = AppConfig.from_env()
            candles = load_candles_csv(args.csv)
            htf_frames = {}
            if args.h1_csv:
                htf_frames["H1"] = load_candles_csv(args.h1_csv)
            if args.h4_csv:
                htf_frames["H4"] = load_candles_csv(args.h4_csv)
            market = analyse_smc(candles, htf_frames, SMCConfig(config.smc_swing_length, config.smc_event_lookback, config.atr_period_smc))
            missing_htf = [tf for tf in config.htf_timeframes if tf not in htf_frames or len(htf_frames[tf]) < 55]
            if missing_htf:
                market["setup_candidate"] = "HOLD"
                market["setup_key"] = "HOLD|HTF_MISSING|" + ",".join(missing_htf)
                market["reasons"].append("Required higher-timeframe CSV missing/short: " + ", ".join(missing_htf) + "; fail closed")
            print(json.dumps(market, indent=2, default=str))
            print("Snapshot only: no Claude call or order submission.", file=sys.stderr)
            return 0

        if args.command == "memory-stats":
            config = AppConfig.from_env()
            db_path = args.db or config.learning_db_path
            memory = LearningMemory(db_path, config.learning_min_setup_sample)
            print(json.dumps({"database": db_path, "summary": memory.summary(), "recent_lessons": memory.recent_lessons(args.recent)}, indent=2, default=str))
            return 0

        if args.command == "demo":
            if not args.confirm_demo:
                print("Blocked. Start with: python main.py demo --confirm-demo", file=sys.stderr)
                print("The terminal must already be logged into a DEMO account. The program independently verifies the account type and rejects real accounts.", file=sys.stderr)
                return 2
            run_demo(AppConfig.from_env(), args.state)
            return 0
    except (ValueError, RuntimeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
