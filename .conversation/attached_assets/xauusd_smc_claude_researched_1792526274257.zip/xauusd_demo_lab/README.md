# XAUUSD Demo Lab — SMC + Trend + Claude Orchestrator

A local Python starter for **XAUUSD demo trading**. The intended architecture is:

1. **Deterministic market-analysis layer:** completed-candle trend, confirmed swing structure, BOS/CHoCH, liquidity-sweep markers, fair-value-gap zones, and opposing-candle order-block proxies.
2. **Higher-timeframe context:** by default, H1 and H4 trends must agree with the setup direction. Missing higher-timeframe context fails closed.
3. **Public research layer:** best-effort DuckDuckGo search results for gold, USD, yields, Fed and inflation context on every new completed execution-timeframe candle. Search results are untrusted evidence and may be stale or unavailable.
4. **Claude Sonnet 4.6 orchestrator:** reviews the deterministic snapshot, research snippets and past trade lessons. Claude may approve the *same* existing BUY/SELL candidate or veto it. It cannot create a setup, reverse its side, change risk, size a position, or override the broker controls.
5. **Local learning memory:** SQLite stores each scan, Claude's decision, setup family and reconciled closed-position outcomes. Subsequent prompts include recent wins/losses and aggregate setup-family fitness. Once a setup family has enough outcomes, a persistently negative or very low-win-rate family is paused.
6. **Independent execution/risk layer:** MT5 demo-account verification, maximum spread, broker-aware volume sizing, attached stop-loss/take-profit, one open position per configured gold symbol, persisted daily equity-loss lock, plus a required command-line acknowledgement.

The “growing like bacteria” idea is represented by *bounded, auditable adaptation*: the memory creates a history of setup families, scores them on their own outcomes, and prevents a repeatedly underperforming family from continuing unchanged. It does **not** modify Claude's model weights. Good historical outcomes do not automatically increase trade risk. A future “evolution” layer could create versioned strategy variants, but those should first be evaluated out-of-sample and promoted only through an explicit ruleset.

## Important limitations

- This is a research/demo starter, not a profitable strategy claim. The SMC implementation is a transparent approximation, not a definitive view of institutional order flow.
- The existing CSV `backtest` command remains the EMA/RSI research baseline from the original starter; it does **not** validate the SMC + Claude live decision policy. Do not interpret baseline results as validation of the live bot.
- No orders are sent from a backtest. Live mode is designed for Windows with MetaTrader 5 connected to a broker DEMO account. No credentials or live account are configured by this repository.
- Claude is called once per newly completed candle (including HOLD candles) and public research is queried each scan when enabled. On M5, this can be a lot of calls. Token usage is metered and SQLite tracks estimated token cost. `ANTHROPIC_DAILY_BUDGET_USD` defaults to $2/day; after that estimate is reached, the runner holds without further Claude calls until the next UTC day. This is an estimated ceiling, and the individual request that crosses it can overshoot slightly. You can set the cap lower, set it to 0 to disable Claude calls, or explicitly raise it after reviewing your budget.
- The public DDGS search source needs no separate key but may rate-limit, change, or fail. Research failures never cause a trade to be approved.
- Gold symbol names, contract size, minimum lots, tick value, spread, stop distance, and order filling rules vary by broker. Verify them in MT5 demo.
- The model is an approval/veto layer, not a source of reliable factual market data. Headlines may be delayed and are not guaranteed to be current.

## Costs and licenses

The project code and Python dependencies are open-source/free to install, and demo access and market data availability depend on the broker. **Claude API use is not free just because you supply an API key.** Anthropic's current Claude Sonnet 4.6 API listing shows $3 per million input tokens and $15 per million output tokens at standard first-party API rates; pricing can change. See the official [Sonnet 4.6 model page](https://platform.claude.com/docs/en/models/sonnet-4-6/overview) and [API pricing](https://platform.claude.com/docs/en/about-claude/pricing). This configuration does not use Anthropic's separate paid web-search tool; it tries a public DDGS search endpoint.

## Installation (Windows for MT5)

Use Python 3.10 or later. MetaTrader 5 execution requires Windows with the MT5 desktop terminal installed; the CSV research tools can run on other operating systems.

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
Copy-Item .env.example .env
```

Edit `.env`:

- Paste your Anthropic API key into `ANTHROPIC_API_KEY` (do not commit/share the file).
- Set `MT5_SYMBOL` to the exact broker symbol, such as `XAUUSD`, `XAUUSDm`, or `XAUUSD.a`.
- Adjust `MAX_SPREAD_PRICE`, and review the risk settings before running.
- Keep `RESEARCH_ENABLED=true` to query public market context on each scan; set it false only if you want price-only review.

Open MetaTrader 5, log in to your broker's **DEMO** account, select the configured XAUUSD symbol in Market Watch, and allow algorithmic trading in the terminal.

## Use the project

### 1) Export candles and inspect SMC context

Export completed candles from MT5 while connected to demo. Run once for M5 and again for each confirmation timeframe:

```powershell
python main.py export-bars --timeframe M5 --bars 5000 --output data\XAUUSD_M5.csv
python main.py export-bars --timeframe H1 --bars 1000 --output data\XAUUSD_H1.csv
python main.py export-bars --timeframe H4 --bars 500 --output data\XAUUSD_H4.csv
```

Inspect the latest setup before turning on Claude or order submission:

```powershell
python main.py analyse-smc --csv data\XAUUSD_M5.csv --h1-csv data\XAUUSD_H1.csv --h4-csv data\XAUUSD_H4.csv
```

The command prints the latest structure/trend snapshot only. Missing configured higher-timeframe data results in `HOLD`.

### 2) Run the baseline CSV backtest

Run the original EMA/RSI baseline backtest, with explicit cost assumptions:

```powershell
python main.py backtest --csv data\XAUUSD_M5.csv --spread 0.30 --slippage 0.05
```

The spread/slippage examples are placeholders; replace them with realistic assumptions from your broker's history. The backtest is *not* the live SMC + LLM strategy.

### 3) Evaluate the SMC technical rules on historical data (no Claude calls)

After exporting timestamped M5, H1 and H4 bars, run the separate causal SMC simulator:

```powershell
python main.py backtest-smc --csv data\XAUUSD_M5.csv --h1-csv data\XAUUSD_H1.csv --h4-csv data\XAUUSD_H4.csv --timeframe M5 --spread 0.30 --slippage 0.05
```

It enters on the next M5 bar after a valid candidate, only includes H1/H4 candles that had fully closed by the signal time, models the explicitly configured spread/slippage, and resolves a candle touching both stop and target as a stop. Output goes to `reports/smc/smc_trades.csv` and `reports/smc/smc_summary.json`.

This validates the deterministic technical candidate layer only. It does not replay Claude decisions, news research, broker fills, or adaptive memory, so it is not a backtest of the complete live/demo system. If the strategy produces no trades, do not relax safety checks just to force trades; inspect the SMC snapshot and data quality first.

### 4) Run the strictly demo-only SMC + Claude orchestrator

```powershell
python main.py demo --confirm-demo
```

The command will fail before connecting to MT5 if `ANTHROPIC_API_KEY` is missing. The program independently checks that the connected account is demo-only at connection and again before sending orders. The code also requires the command-line acknowledgement `--confirm-demo`.

### 5) Inspect learned memory and API spend

```powershell
python main.py memory-stats
```

This displays scan count, closed-position outcomes, setup-family fitness and estimated Claude API spend. The SQLite database and daily loss state stay local under `state/` by default.

### 6) Run automated tests

```powershell
python -m pytest -q
```

## Configuration

| Variable | Default | Meaning |
|---|---:|---|
| `ANTHROPIC_MODEL` | `claude-sonnet-4-6` | LLM model ID |
| `ANTHROPIC_CONFIDENCE_THRESHOLD` | `0.70` | Minimum Claude confidence for same-side approval |
| `ANTHROPIC_MAX_TOKENS` | `650` | Upper bound on response size per scan |
| `ANTHROPIC_DAILY_BUDGET_USD` | `2.00` | Estimated daily token-spend cap; reached cap makes all remaining scans HOLD |
| `ANTHROPIC_INPUT_USD_PER_MTOK` | `3.00` | Input-token rate used for local cost estimates (USD / million tokens) |
| `ANTHROPIC_OUTPUT_USD_PER_MTOK` | `15.00` | Output-token rate used for local cost estimates (USD / million tokens) |
| `SMC_SWING_LENGTH` | `3` | Number of candles on either side needed to confirm swing points |
| `SMC_EVENT_LOOKBACK` | `20` | Recent window used for structure/sweep/zone context |
| `HTF_TIMEFRAMES` | `H1,H4` | Higher-timeframe trend confirmation |
| `RESEARCH_ENABLED` | `true` | Try public search every completed candle |
| `RESEARCH_MAX_RESULTS` | `3` | Maximum research results provided per scan |
| `LEARNING_DB_PATH` | `state/learning.sqlite3` | Persistent local SQLite memory |
| `LEARNING_MIN_SETUP_SAMPLE` | `8` | Minimum closed trades before a setup family may be paused |
| `RISK_PER_TRADE_PCT` | `0.25` | Equity risk estimate per trade, percent |
| `DAILY_LOSS_LIMIT_PCT` | `2.0` | Persisted UTC-day loss lock |
| `MAX_SPREAD_PRICE` | `1.50` | Hard block when observed XAUUSD spread is larger |

## Design / safety policy

- Claude sees only compact closed-candle features and bounded search snippets, not broker credentials.
- Web search results are treated as untrusted data. Claude cannot invoke tools, place orders, or run code.
- A trade is considered only if SMC independently emits BUY/SELL, the execution-timeframe trend agrees, all configured higher timeframes agree, a prior liquidity sweep plus aligned zone are present, and Claude approves the same side above threshold with no risk flags.
- A Claude error, invalid response, missing HTF context, paused setup family, reached API budget, or invalid ATR fails closed. Public search failure is recorded and removes external context but never weakens deterministic guards.
- The bot does not modify or close an existing position. Verify the broker-side stop-loss and take-profit directly. Ctrl+C stops the process but does not close positions.
- Never put your API key in source code, screenshots, issues or a public repository. Keep `.env` private.

## Repository research

See [`REPOSITORY_REVIEW.md`](REPOSITORY_REVIEW.md) for the role-based review of the 20 unique repositories supplied for this project. See [`REPOSITORY_RESEARCH_IMPLEMENTED.md`](REPOSITORY_RESEARCH_IMPLEMENTED.md) for additional GitHub repositories mapped to each subsystem and what was implemented from those design ideas.
