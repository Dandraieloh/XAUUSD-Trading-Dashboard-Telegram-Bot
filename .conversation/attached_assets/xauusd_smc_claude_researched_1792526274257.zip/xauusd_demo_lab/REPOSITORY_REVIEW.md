# Repository review for XAUUSD demo trading

Reviewed 20 unique repositories from the supplied list (three URL repetitions: NoFx, StockSharp, and ai_quant_trade). This is an implementation-fit review, not a security audit of every source file, dependency or license.

## How the recommendations were used

The starter borrows architectural ideas rather than copying or bundling upstream source: keep strategy code separate from execution, use a backtesting step before forward testing, use broker-reported instrument economics for sizing, and keep agent/LLM opinions out of automatic order submission. XAUUSD CFD/spot symbols have broker-specific contract size, tick value, symbol names, spreads and order rules, so those details must be discovered from the demo account rather than assumed universally.

| Repository | Main purpose / useful ideas | Fit for this XAUUSD demo | Decision |
|---|---|---|---|
| [QuantConnect/Lean](https://github.com/QuantConnect/Lean) | Modular event-driven engine for backtests and live trading across markets; Python/C# workflow and CLI. | Strong long-term research engine, but substantial runtime/data/broker setup for a single MT5 gold strategy. | Reference architecture, not embedded. |
| [nautechsystems/nautilus_trader](https://github.com/nautechsystems/nautilus_trader) | Rust-native event-driven engine, shared strategy across simulation, sandbox and live modes, multi-venue data/execution. | Strong choice if scaling to a more formal multi-venue system; likely overkill for a small starter and MT5-specific demo requirement. | Future upgrade candidate. |
| [StockSharp/StockSharp](https://github.com/StockSharp/StockSharp) | .NET algo-trading platform and connector ecosystem including several FX/MT5-related integration paths. | Broker connectivity is relevant, but introduces a separate .NET stack and its own adapter semantics. | Connectivity reference. |
| [deepentropy/tvscreener](https://github.com/deepentropy/tvscreener) | Python TradingView screener wrapper with forex screener support. | Useful for discovery/watchlists, not an execution API or guaranteed quote source. | Optional research only; not required by the runtime. |
| [NoFxAiOS/nofx](https://github.com/NoFxAiOS/nofx) | AI trading terminal with human-approved trade plans and continuous Autopilot; the current README lists Binance, Hyperliquid, OKX and Bitget in Frontier, plus additional exchange connectors in the broader runtime. The repository is AGPL-3.0 licensed. | Its AI workflows cover several market categories, but the published execution integrations are exchange-focused rather than the MT5 broker demo account targeted here. Its Autopilot can continuously place orders, so agent decisions need independent risk gates. | Not imported or used to submit orders. Avoid copying source into a differently licensed project without reviewing AGPL obligations; re-evaluate only if the actual venue matches. |
| [HKUDS/AI-Trader](https://github.com/HKUDS/AI-Trader) | Agent-native platform aimed at automated trading-agent workflows. | Interesting agent orchestration, but not a substitute for tested XAUUSD market data, realistic execution simulation and broker risk controls. | Research only. |
| [Fincept-Corporation/FinceptTerminal](https://github.com/Fincept-Corporation/FinceptTerminal) | Finance terminal with analytics, data exploration and research functions. | Potential separate desktop research interface; not needed in a small Python execution loop. | Optional UI/research reference. |
| [vnpy/vnpy](https://github.com/vnpy/vnpy) | Event-driven Python quantitative trading platform with gateways and strategy APIs. | Strong modular trading framework, especially if a supported gateway fits the broker. It is a broader platform than needed here. | Future framework candidate. |
| [HKUDS/Vibe-Trading](https://github.com/HKUDS/Vibe-Trading) | AI trading research toolkit, strategy/backtest workflows, multi-agent research and connectors. | Useful for research experiments; do not permit an LLM to directly bypass deterministic execution safety. | Optional offline research only. |
| [TauricResearch/TradingAgents](https://github.com/TauricResearch/TradingAgents) | Multi-agent LLM financial analysis and debate framework. | Designed as a research/decision-support framework; not the base of a hard-real-time gold order executor. | Excluded from execution. |
| [paperswithbacktest/awesome-systematic-trading](https://github.com/paperswithbacktest/awesome-systematic-trading) | Curated list of quantitative research libraries, tools, papers, strategies and books. | Excellent index for future tool selection, but not an engine itself. | Reading/reference list. |
| [bbfamily/abu](https://github.com/bbfamily/abu) | Quantitative strategy toolkit/tutorials and technical-pattern research. | Some useful legacy strategy examples, but not an ideal new broker-execution layer. | Research reference only. |
| [quantopian/zipline](https://github.com/quantopian/zipline) | Event-driven Python backtesting library originally built around Quantopian workflows. | Useful backtesting history, but compatibility, data model and maintenance fit should be checked before selecting it for a new FX/CFD pipeline. | Not embedded. |
| [stefan-jansen/machine-learning-for-trading](https://github.com/stefan-jansen/machine-learning-for-trading) | Book companion covering data, features, ML research, backtesting and deployment. | Strong learning reference for later feature/model work; it is not a plug-and-play gold trader. | Reference for future research. |
| [charliedream1/ai_quant_trade](https://github.com/charliedream1/ai_quant_trade) | Traditional and ML-oriented quantitative strategy examples. | Good experimentation source, but repository experiments require validation and realistic cost modeling before broker deployment. | Not imported. |
| [ricequant/rqalpha](https://github.com/ricequant/rqalpha) | Extendable strategy backtest/trading framework for multiple securities. | Broad backtesting support; ecosystem and instrument-model assumptions are not the shortest route to broker-specific XAUUSD CFD execution. | Not embedded. |
| [ghostfolio/ghostfolio](https://github.com/ghostfolio/ghostfolio) | Self-hosted wealth/portfolio tracking and performance visualization. | Portfolio reporting rather than strategy execution. | Possible later reporting integration. |
| [polakowo/vectorbt](https://github.com/polakowo/vectorbt) | Fast vectorized portfolio analysis and parameter sweeps built around pandas/NumPy. | Very useful for larger strategy sweeps once cleaned market data and explicit costs are available. | Future research extension; starter includes an interpretable OHLC backtester. |
| [Mathieu2301/TradingView-API](https://github.com/Mathieu2301/TradingView-API) | Community, unofficial TradingView data/chart API for candles, quotes and indicators. | Convenient prototype data source, but not official; avoid making execution correctness depend on an unofficial feed. | Not used; MT5 broker candles are preferred for broker-specific testing. |
| [Superalgos/Superalgos](https://github.com/Superalgos/Superalgos) | Visual trading and data/backtesting workflows with primary focus on crypto-oriented strategies. | Less direct for broker-based XAUUSD CFD orders. | Not selected for this target. |

## Updated design decision: SMC + trend + research + Claude

The current starter now implements a focused execution path rather than adding every framework as a dependency:

- **Market structure (`xau_demo/smc.py`):** confirmed swing points, BOS/CHoCH labels, buy-side/sell-side liquidity sweep markers, active three-candle FVGs, and opposing-candle order-block proxies. Every decision is made from completed candles. This is a deterministic approximation, not actual institutional order-book or dealer-positioning data.
- **Trend filter:** EMA20/EMA50 direction and EMA slope on the execution timeframe plus H1/H4 context by default. Missing required HTF data forces HOLD.
- **Research (`xau_demo/research.py`):** tries public DDGS text search each new candle without an additional search API key. Public search can change or rate-limit; research is not guaranteed to be fresh or complete.
- **Orchestrator (`xau_demo/orchestrator.py`):** Claude Sonnet 4.6 reviews the snapshot, research and past outcomes. A pure policy gate permits only the same side as the existing deterministic candidate, above the configured confidence threshold with no model risk flags. Claude cannot create or reverse signals.
- **Learning loop (`xau_demo/memory.py`):** SQLite records scans, model decisions, position associations, closed-position P&L and setup-family fitness. The system passes recent outcomes back into future review and pauses an exact setup family after at least the configured sample count when net P&L is non-positive or win rate is below 35%. Successful setup families never auto-increase risk. This is bounded learning from outcomes, not fine-tuning or changing Claude's weights.
- **Cost and order gate:** Claude's token use is estimated and logged locally; the default daily estimate cap is USD 2, after which the system stays in HOLD until the next UTC date. The MT5 order path independently re-checks the account is DEMO.

The existing CLI's CSV backtest still tests the earlier EMA/RSI baseline and must **not** be presented as evidence of profitability for the SMC + Claude live path. A dedicated walk-forward simulator for this combined policy would be the next important research milestone before long demo-forward-testing.

The implementation is intentionally not a mash-up of all 20 repositories: each has its own APIs, dependencies, data assumptions and license. Integrating them all would increase failure modes without improving trade safety. Check each upstream license, supported broker/market, and current dependency versions before importing or redistributing its code.

## Sources checked

- LEAN overview and CLI: https://github.com/QuantConnect/Lean
- NautilusTrader overview and supported simulation/live modes: https://github.com/nautechsystems/nautilus_trader
- StockSharp platform/connectors: https://github.com/StockSharp/StockSharp
- TradingView screener usage and forex screener: https://github.com/deepentropy/tvscreener
- AI-Trader: https://github.com/HKUDS/AI-Trader
- FinceptTerminal: https://github.com/Fincept-Corporation/FinceptTerminal
- vn.py: https://github.com/vnpy/vnpy
- Vibe-Trading: https://github.com/HKUDS/Vibe-Trading
- TradingAgents: https://github.com/TauricResearch/TradingAgents
- Awesome Systematic Trading: https://github.com/paperswithbacktest/awesome-systematic-trading
- ABU: https://github.com/bbfamily/abu
- Zipline: https://github.com/quantopian/zipline
- Machine Learning for Trading: https://github.com/stefan-jansen/machine-learning-for-trading
- ai_quant_trade: https://github.com/charliedream1/ai_quant_trade
- RQAlpha: https://github.com/ricequant/rqalpha
- Ghostfolio: https://github.com/ghostfolio/ghostfolio
- vectorbt: https://github.com/polakowo/vectorbt
- TradingView-API: https://github.com/Mathieu2301/TradingView-API
- Superalgos: https://github.com/Superalgos/Superalgos
- NoFx: https://github.com/NoFxAiOS/nofx
- SMC feature concepts (reference only; this project uses its own transparent approximation): https://github.com/joshyattridge/smart-money-concepts
- Claude Sonnet 4.6 model identifier and pricing: https://platform.claude.com/docs/en/models/sonnet-4-6/overview
- Anthropic API pricing: https://platform.claude.com/docs/en/about-claude/pricing
