import numpy as np
import pandas as pd
import pytest

from xau_demo.smc_backtest import run_smc_backtest


def candles(n=100, start="2026-01-01T00:00:00Z", freq="5min"):
    close = 2300 + np.arange(n) * 0.08 + np.sin(np.arange(n) / 3) * 0.3
    return pd.DataFrame({
        "time": pd.date_range(start, periods=n, freq=freq, tz="UTC"),
        "open": close - 0.05, "high": close + 0.3, "low": close - 0.3, "close": close,
    })


def test_smc_backtest_requires_real_timestamps():
    frame = candles().drop(columns="time")
    with pytest.raises(ValueError, match="real time column"):
        run_smc_backtest(frame, execution_timeframe="M5")


def test_smc_backtest_returns_explicit_rule_only_summary():
    frame = candles(130)
    trades, summary = run_smc_backtest(
        frame, higher_timeframes={}, execution_timeframe="M5", initial_equity=10000,
    )
    assert summary["strategy"] == "causal_smc_rules_only_no_llm"
    assert summary["assumptions"]["llm"].startswith("excluded")
    assert summary["initial_equity"] == 10000
    assert isinstance(trades, pd.DataFrame)


def test_smc_backtest_rejects_invalid_costs():
    with pytest.raises(ValueError, match="costs non-negative"):
        run_smc_backtest(candles(), assumed_spread_price=-0.1)
