from datetime import datetime, timezone

import pandas as pd

from xau_demo.mt5_adapter import MT5Adapter


class FakeMT5:
    TIMEFRAME_M5 = 5

    def copy_rates_from_pos(self, symbol, timeframe, start_pos, count):
        # Deliberately unordered data. The newest candle is the currently forming bar.
        base = int(datetime(2026, 1, 1, tzinfo=timezone.utc).timestamp())
        rows = []
        for minutes in (20, 0, 15, 5, 10):
            price = 2300.0 + minutes
            rows.append({
                "time": base + minutes * 60,
                "open": price,
                "high": price + 1,
                "low": price - 1,
                "close": price + 0.5,
                "tick_volume": 10,
                "spread": 2,
                "real_volume": 0,
            })
        return rows

    def last_error(self):
        return (0, "ok")


def test_closed_bars_are_sorted_and_drop_current_forming_candle():
    adapter = MT5Adapter("XAUUSD", "M5")
    adapter.mt5 = FakeMT5()
    bars = adapter.closed_bars(count=3)
    assert len(bars) == 3
    assert bars["time"].is_monotonic_increasing
    # Latest completed bar is minute 15; minute 20 is the forming candle and excluded.
    assert bars.iloc[-1]["time"] == pd.Timestamp("2026-01-01T00:15:00Z")
