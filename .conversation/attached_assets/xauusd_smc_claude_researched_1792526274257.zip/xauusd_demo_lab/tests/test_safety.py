from types import SimpleNamespace

import pytest

from xau_demo.mt5_adapter import MT5Adapter, SafetyStop


class FakeRealAccountMT5:
    ACCOUNT_TRADE_MODE_DEMO = 0

    def __init__(self):
        self.sent = False

    def account_info(self):
        return SimpleNamespace(trade_mode=1)  # REAL account mode

    def last_error(self):
        return (0, "ok")

    def order_send(self, request):
        self.sent = True
        raise AssertionError("order_send must never be reached on a real account")


def test_order_submission_is_blocked_before_order_send_on_non_demo_account():
    fake = FakeRealAccountMT5()
    adapter = MT5Adapter("XAUUSD", "M5")
    adapter.mt5 = fake
    with pytest.raises(SafetyStop, match="not a DEMO account"):
        adapter.place_market_order(1, 0.01, 2290.0, 2320.0, 20, 20261020)
    assert fake.sent is False
