import numpy as np
import pandas as pd

from xau_demo.smc import SMCConfig, _confirm_swings, analyse_smc, calculate_trend


def candles(n=140, slope=0.08):
    x = np.arange(n, dtype=float)
    close = 2300 + x * slope + np.sin(x / 3) * 2.0
    open_ = close - np.sin(x / 2) * 0.6
    high = np.maximum(open_, close) + 0.8 + (x % 4) * 0.05
    low = np.minimum(open_, close) - 0.8 - (x % 3) * 0.04
    return pd.DataFrame({"time": pd.date_range("2026-01-01", periods=n, freq="5min", tz="UTC"), "open": open_, "high": high, "low": low, "close": close})


def test_swing_is_only_marked_when_right_side_bars_confirm_it():
    frame = pd.DataFrame({
        "open": [1] * 15,
        "high": [10, 11, 12, 11, 12, 20, 13, 12, 11, 10, 11, 12, 11, 10, 9],
        "low": [0, 1, 2, 1, 2, 3, 3, 2, 1, 0, 1, 2, 1, 0, -1],
        "close": [5] * 15,
    })
    confirmed_high, _ = _confirm_swings(frame, strength=2)
    assert confirmed_high[5] is None
    assert confirmed_high[7] == 20.0


def test_smc_returns_hold_when_higher_timeframe_context_is_missing():
    snap = analyse_smc(candles(), higher_timeframes={}, config=SMCConfig())
    assert snap["setup_candidate"] == "HOLD"
    assert snap["execution_policy"].startswith("CLOSED_CANDLES_ONLY")
    assert "atr" in snap and snap["atr"] > 0


def test_trend_output_is_explicit_and_json_friendly():
    result = calculate_trend(candles())
    assert result["direction"] in {"BULLISH", "BEARISH", "RANGING"}
    assert isinstance(result["ema20"], float)
