from main import main


def test_demo_command_requires_explicit_confirmation(capsys):
    code = main(["demo"])
    assert code == 2
    assert "Blocked" in capsys.readouterr().err


def test_demo_with_ack_but_missing_api_key_fails_before_mt5(monkeypatch, capsys):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "")
    code = main(["demo", "--confirm-demo"])
    captured = capsys.readouterr()
    assert code == 1
    assert "ANTHROPIC_API_KEY" in captured.err
    assert "MT5 initialize" not in captured.err
