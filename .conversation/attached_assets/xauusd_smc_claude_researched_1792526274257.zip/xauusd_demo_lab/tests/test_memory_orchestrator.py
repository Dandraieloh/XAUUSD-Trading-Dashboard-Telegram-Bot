from types import SimpleNamespace

from xau_demo.memory import LearningMemory
from xau_demo.orchestrator import _parse_json, enforce_decision_policy


def test_claude_cannot_create_or_reverse_a_setup():
    response = {"action": "BUY", "approve": True, "confidence": 0.99, "risk_flags": []}
    blocked = enforce_decision_policy(response, {"setup_candidate": "HOLD"}, 0.7)
    assert blocked["final_action"] == "HOLD"
    assert not blocked["approved_by_policy"]
    reversed_side = enforce_decision_policy({**response, "action": "SELL"}, {"setup_candidate": "BUY"}, 0.7)
    assert reversed_side["final_action"] == "HOLD"
    approved = enforce_decision_policy(response, {"setup_candidate": "BUY"}, 0.7)
    assert approved["final_action"] == "BUY"
    assert approved["approved_by_policy"]
    flagged = enforce_decision_policy({**response, "risk_flags": ["NEWS_UNCLEAR"]}, {"setup_candidate": "BUY"}, 0.7)
    assert flagged["final_action"] == "HOLD"


def test_model_json_is_normalized_and_bad_confidence_fails_low():
    parsed = _parse_json('```json\n{"action":"BUY","approve":true,"confidence":7,"risk_flags":[]}\n```')
    assert parsed["action"] == "BUY"
    assert parsed["confidence"] == 1.0
    assert parsed["approve"] is True


def test_memory_records_closed_position_once_and_pauses_weak_setup(tmp_path):
    memory = LearningMemory(tmp_path / "memory.sqlite3", min_setup_sample=3)
    setup = "BUY|BOS_UP|SELL_SIDE_SWEEP|FVG|H1:BULLISH,H4:BULLISH"
    for pid in (101, 102, 103):
        memory.register_position(pid, "XAUUSD", setup, "BUY", {
            "close": 2300.0,
            "trend": {"direction": "BULLISH"},
            "structure_event": "BOS_UP",
            "orchestrator_record": {"thesis": f"test thesis {pid}", "research_status": "ok"},
        })
        deals = [
            SimpleNamespace(position_id=pid, ticket=pid + 1000, entry=0, time=100, profit=0.0, commission=-0.2, swap=0.0, fee=0.0),
            SimpleNamespace(position_id=pid, ticket=pid + 2000, entry=1, time=200 + pid, profit=-2.0, commission=-0.2, swap=0.0, fee=0.0),
        ]
        assert memory.sync_closed_deals(deals, set()) == 1
        assert memory.sync_closed_deals(deals, set()) == 0
    paused, reason = memory.setup_is_paused(setup)
    assert paused
    assert "paused" in reason
    summary = memory.summary()
    assert summary["closed_positions"] == 3
    assert summary["net_pnl"] < 0
    lessons = memory.recent_lessons(12)
    trade_lessons = [lesson for lesson in lessons if lesson["kind"] == "closed_trade"]
    assert trade_lessons and trade_lessons[0]["entry_thesis"].startswith("test thesis")


def test_api_usage_meter_enforces_daily_estimated_budget(tmp_path):
    memory = LearningMemory(tmp_path / "budget.sqlite3")
    memory.record_api_usage("claude-sonnet-4-6", 100_000, 1_000)
    spent = memory.estimated_api_spend_today()
    assert abs(spent - 0.315) < 1e-9
    allowed, _ = memory.can_call_llm(0.30)
    assert not allowed
    allowed, _ = memory.can_call_llm(1.00)
    assert allowed
    blocked, _ = memory.can_call_llm(0)
    assert not blocked
