from datetime import datetime, timezone

from xau_demo.risk import DailyLossGuard, calculate_volume


def test_volume_never_exceeds_risk_budget():
    volume, risk = calculate_volume(
        equity=10_000,
        risk_pct=0.25,
        stop_distance_price=5.0,
        tick_size=0.01,
        tick_value=1.0,
        volume_min=0.01,
        volume_max=100.0,
        volume_step=0.01,
        hard_max_volume=2.0,
    )
    assert volume > 0
    assert risk <= 25.0
    assert abs(volume / 0.01 - round(volume / 0.01)) < 1e-7


def test_volume_rejects_min_lot_that_would_break_risk_budget():
    volume, risk = calculate_volume(
        equity=100,
        risk_pct=0.25,
        stop_distance_price=100,
        tick_size=0.01,
        tick_value=1.0,
        volume_min=0.01,
        volume_max=100,
        volume_step=0.01,
        hard_max_volume=1.0,
    )
    assert volume == 0
    assert risk == 0


def test_daily_guard_latches_after_limit_and_keeps_baseline(tmp_path):
    guard = DailyLossGuard(tmp_path / "day.json", 2.0)
    day = datetime(2026, 10, 20, 10, 0, tzinfo=timezone.utc)
    allowed, _ = guard.can_open_new_trade(10_000, day)
    assert allowed
    allowed, message = guard.can_open_new_trade(9_790, day)
    assert not allowed
    assert "guard active" in message.lower()
    allowed, _ = guard.can_open_new_trade(9_950, day)
    assert not allowed


def test_daily_guard_resets_on_new_utc_day(tmp_path):
    guard = DailyLossGuard(tmp_path / "day.json", 2.0)
    first = datetime(2026, 10, 20, 23, 55, tzinfo=timezone.utc)
    next_day = datetime(2026, 10, 21, 0, 5, tzinfo=timezone.utc)
    guard.can_open_new_trade(10_000, first)
    allowed, _ = guard.can_open_new_trade(9_700, first)
    assert not allowed
    allowed, message = guard.can_open_new_trade(9_700, next_day)
    assert allowed
    assert "0.00%" in message
