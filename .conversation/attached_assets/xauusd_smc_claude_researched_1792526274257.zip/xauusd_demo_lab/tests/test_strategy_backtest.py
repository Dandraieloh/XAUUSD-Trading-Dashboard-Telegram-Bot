import numpy as np
import pandas as pd

from xau_demo.backtest import run_backtest
from xau_demo.config import StrategyConfig
from xau_demo.strategy import add_indicators


def make_candles(n=600):
    rng = np.random.default_rng(7)
    # Deterministic synthetic data for software tests only; not market history.
    changes = rng.normal(loc=0.0, scale=0.7, size=n) + 0.015 * np.sin(np.arange(n) / 15)
    close = 2350 + np.cumsum(changes)
    open_ = np.concatenate([[close[0]], close[:-1]])
    high = np.maximum(open_, close) + rng.uniform(0.05, 0.45, n)
    low = np.minimum(open_, close) - rng.uniform(0.05, 0.45, n)
    return pd.DataFrame({
        "time": pd.date_range("2025-01-01", periods=n, freq="5min", tz="UTC"),
        "open": open_, "high": high, "low": low, "close": close,
    })


def test_indicators_and_signals_have_expected_columns():
    cfg = StrategyConfig(fast_ema=8, slow_ema=21, rsi_period=7, atr_period=7)
    out = add_indicators(make_candles(), cfg)
    assert {"ema_fast", "ema_slow", "rsi", "atr", "signal"}.issubset(out.columns)
    assert set(out["signal"].unique()).issubset({-1, 0, 1})
    assert out["atr"].dropna().gt(0).all()


def test_backtest_returns_report_and_respects_equity_schema():
    cfg = StrategyConfig(fast_ema=8, slow_ema=21, rsi_period=7, atr_period=7,
                         long_rsi_min=45, long_rsi_max=80, short_rsi_min=20, short_rsi_max=55)
    trades, summary = run_backtest(make_candles(), strategy=cfg, initial_equity=10_000, risk_pct=0.25)
    assert summary["initial_equity"] == 10_000
    assert "ending_equity" in summary and "max_closed_trade_drawdown_pct" in summary
    assert isinstance(trades, pd.DataFrame)
    if not trades.empty:
        assert {"entry_time", "side", "volume", "pnl", "equity_after"}.issubset(trades.columns)
        assert trades["volume"].ge(0.01).all()
