# Repository research translated into implementation decisions

This project borrows design ideas and testing targets, not copied source code. Review the upstream repositories and their current licenses before adopting any code directly.

## Aspect-by-aspect shortlist

| Aspect | Repository | What is useful | What this project takes from it / current limitation |
|---|---|---|---|
| SMC features | [Prasad1612/smart-money-concept](https://github.com/Prasad1612/smart-money-concept) | BOS/CHoCH, order blocks, FVGs, equal highs/lows, premium/discount visualizations | Keep our causal confirmed-swing implementation and test definitions against known examples. The upstream README uses Yahoo Finance and is not an MT5 gold data adapter. |
| SMC strategy prototype | [shrv797/smart-money-concepts-trading-system](https://github.com/shrv797/smart-money-concepts-trading-system) | EMA/ATR, swing structure, BOS/CHoCH, sample datasets | Useful as a concept checklist, but README describes work in progress and example datasets are BTC, not XAUUSD validation. |
| Execution framework patterns | [freqtrade/freqtrade](https://github.com/freqtrade/freqtrade) | Dry-run first, explicit exchange constraints, strategy interfaces, backtesting and reports | We keep MT5 as the target venue; Freqtrade is crypto/exchange-focused, not a direct XAUUSD MT5 connector. |
| Research/backtest analysis | [polakowo/vectorbt](https://github.com/polakowo/vectorbt) | Vectorized parameter sweeps and portfolio statistics | Candidate for offline research once the event-based SMC policy is validated. Not installed as a runtime dependency. |
| Backtesting methodology | [kernc/backtesting.py](https://github.com/kernc/backtesting.py) | Event-driven bar simulation and explicit order/position lifecycle | Current backtests use explicit next-bar entry and stop-first same-bar resolution. Consider this framework for richer commissions, partial exits and order types. |
| Financial ML validation | [mlfinlab](https://github.com/hudson-and-thames/mlfinlab) | Purged CV, embargo, labeling, portfolio/risk research concepts | No ML model is trained by the current bot. Do not add financial ML until leakage-safe labels and walk-forward evaluation are implemented. Check current source availability/license before adoption. |
| LLM orchestration | [Auth3nticAI/claude-tool-use-agent](https://github.com/Auth3nticAI/claude-tool-use-agent) | Bounded tool loop, structured steps, explicit tool-result audit trail | Claude currently reviews a compact market snapshot and cannot call tools or submit orders. A bounded research-tool loop can be added later without giving the model execution privileges. |
| Broker abstraction | [QuantConnect LEAN](https://github.com/QuantConnect/Lean), [NautilusTrader](https://github.com/nautechsystems/nautilus_trader) | Separating strategy, data, execution, event lifecycle and simulation | Keep MT5 behind `MT5Adapter`; migrating to a general event-driven engine is a larger architectural step, not a safe drop-in change. |
| News research | [OpenBB](https://github.com/OpenBB-finance/OpenBB) | Pluggable market-data and research providers | Current public search is best-effort and may rate-limit. Treat headlines as untrusted context, never as a direct trade trigger. |
| Exchange APIs | [CCXT](https://github.com/ccxt/ccxt) | Broad crypto exchange API unification | Not appropriate for XAUUSD OTC/CFD MT5 execution unless the actual venue is a supported exchange. |

## Implemented in this update

- Added `backtest-smc`, a rule-only SMC historical simulator that never calls Claude and never connects to MT5.
- Requires real timestamps and uses completed higher-timeframe bars only; it avoids including an H1/H4 candle before its close time.
- Enters at the next execution bar open, includes declared spread/slippage, sizes down by the declared lot step, uses ATR stops and fixed reward/risk targets, and resolves ambiguous bars pessimistically by assuming the stop is hit first.
- Emits a trade CSV and JSON summary, explicitly labeling that the result validates only technical SMC candidate logic, not Claude's judgment or the demo execution path.
- Added tests for timestamp requirements, summary contract and cost validation.

## Still needed before relying on results

1. Use broker-exported XAUUSD candles with correct timezone and exact symbol.
2. Confirm spread, slippage, contract size, lot step and tick economics from the broker.
3. Add an out-of-sample walk-forward protocol and compare against simple baselines.
4. Validate SMC events on hand-labelled chart examples; SMC terms are not universally standardized.
5. Record LLM input/output and decisions with prompt/model version, then replay decisions offline where possible.
6. Paper trade on demo for a meaningful period and review every execution and stop placement.
7. Keep all model output outside the risk/execution trust boundary. A positive backtest is not evidence of future profitability.
